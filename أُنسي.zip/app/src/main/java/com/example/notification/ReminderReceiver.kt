package com.example.notification

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R

class ReminderReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val type = intent.getStringExtra("REMINDER_TYPE") ?: "GENERAL"
        val title = intent.getStringExtra("REMINDER_TITLE") ?: "رفيقك أُنسي"
        val message = intent.getStringExtra("REMINDER_MESSAGE") ?: "حان وقت ذكر الله وطمأنينة القلب"

        showNotification(context, title, message, type)
    }

    companion object {
        const val CHANNEL_ID = "unsi_reminders_channel"

        fun showNotification(context: Context, title: String, message: String, type: String) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    "تذكيرات أُنسي الإيمانية",
                    NotificationManager.IMPORTANCE_DEFAULT
                ).apply {
                    description = "تنبيهات أذكار الصباح والمساء ومحاسبة النفس ومواقيت الصلاة"
                }
                notificationManager.createNotificationChannel(channel)
            }

            val targetRoute = when (type) {
                "SABAH" -> "adhkar_category/sabah"
                "MASAA" -> "adhkar_category/masaa"
                "MUHASABA" -> "muhasaba"
                "PRAYER" -> "prayer_times"
                else -> "home"
            }

            val appIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                putExtra("destination", targetRoute)
            }

            val pendingIntent = PendingIntent.getActivity(
                context,
                type.hashCode(),
                appIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val builder = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(title)
                .setContentText(message)
                .setStyle(NotificationCompat.BigTextStyle().bigText(message))
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)

            notificationManager.notify(type.hashCode(), builder.build())
        }
    }
}
