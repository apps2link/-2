package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.TouchApp
import androidx.compose.material.icons.outlined.WbSunny
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.IslamicBackgroundPattern
import com.example.ui.screens.AdhkarCategoriesScreen
import com.example.ui.screens.AudioPlayerScreen
import com.example.ui.screens.CompanionScreen
import com.example.ui.screens.CustomizationScreen
import com.example.ui.screens.DhikrCategoryListScreen
import com.example.ui.screens.DhikrDetailScreen
import com.example.ui.screens.FavoritesScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MuhasabaScreen
import com.example.ui.screens.OnboardingScreen
import com.example.ui.screens.PrayerTimesScreen
import com.example.ui.screens.QiblaScreen
import com.example.ui.screens.QuranCatalogScreen
import com.example.ui.screens.QuranReaderScreen
import com.example.ui.screens.SearchScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.StatisticsScreen
import com.example.ui.screens.TasbihScreen
import com.example.ui.screens.WidgetGuideScreen
import com.example.ui.screens.WirdPlanScreen
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldRadiant
import com.example.ui.theme.UnsiTheme
import com.example.ui.viewmodel.MainViewModel

data class NavItem(
    val route: String,
    val title: String,
    val iconFilled: ImageVector,
    val iconOutlined: ImageVector
)

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val initialDestination = intent?.getStringExtra("destination") ?: "home"

        setContent {
            val viewModel: MainViewModel = viewModel()
            val userSettings by viewModel.userSettings.collectAsState()

            UnsiTheme(themeMode = userSettings.themeMode) {
                IslamicBackgroundPattern(enableAnimation = userSettings.ambientDecorationsEnabled) {
                    if (!userSettings.firstLaunchCompleted) {
                        OnboardingScreen(
                            viewModel = viewModel,
                            onFinish = { /* state triggers recomposition */ }
                        )
                    } else {
                        MainAppContent(
                            viewModel = viewModel,
                            initialRoute = initialDestination
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun MainAppContent(
    viewModel: MainViewModel,
    initialRoute: String = "home"
) {
    val navStack = remember { mutableStateListOf(initialRoute) }
    val currentRoute = navStack.lastOrNull() ?: "home"

    // Contextual arguments
    var currentCategoryId by remember { mutableStateOf("sabah") }
    var currentDhikrId by remember { mutableStateOf("sabah_1") }
    var currentSurahNumber by remember { mutableIntStateOf(1) }

    fun navigateTo(route: String) {
        if (route.startsWith("adhkar_category/")) {
            currentCategoryId = route.removePrefix("adhkar_category/")
            navStack.add("adhkar_category_detail")
        } else if (route.startsWith("dhikr_detail/")) {
            currentDhikrId = route.removePrefix("dhikr_detail/")
            navStack.add("dhikr_detail")
        } else if (route.startsWith("quran_reader/")) {
            currentSurahNumber = route.removePrefix("quran_reader/").toIntOrNull() ?: 1
            navStack.add("quran_reader")
        } else if (route.startsWith("audio_player/")) {
            currentSurahNumber = route.removePrefix("audio_player/").toIntOrNull() ?: 1
            navStack.add("audio_player")
        } else {
            if (currentRoute != route) {
                navStack.add(route)
            }
        }
    }

    fun popBack() {
        if (navStack.size > 1) {
            navStack.removeAt(navStack.size - 1)
        }
    }

    BackHandler(enabled = navStack.size > 1) {
        popBack()
    }

    val bottomNavItems = listOf(
        NavItem("home", "الرئيسية", Icons.Default.Home, Icons.Outlined.Home),
        NavItem("adhkar", "الأذكار", Icons.Default.WbSunny, Icons.Outlined.WbSunny),
        NavItem("tasbih", "السبحة", Icons.Default.TouchApp, Icons.Outlined.TouchApp),
        NavItem("quran", "المصحف", Icons.Default.MenuBook, Icons.Outlined.MenuBook),
        NavItem("companion", "رفيق أُنسي", Icons.Default.AutoAwesome, Icons.Outlined.AutoAwesome)
    )

    val isTopLevelRoute = currentRoute in listOf("home", "adhkar", "tasbih", "quran", "companion")

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            if (isTopLevelRoute) {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, GoldRadiant.copy(alpha = 0.25f)),
                    modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
                ) {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface,
                        tonalElevation = 0.dp
                    ) {
                        bottomNavItems.forEach { item ->
                            val isSelected = currentRoute == item.route
                            NavigationBarItem(
                                selected = isSelected,
                                onClick = {
                                    if (currentRoute != item.route) {
                                        navStack.clear()
                                        navStack.add(item.route)
                                    }
                                },
                                icon = {
                                    Icon(
                                        imageVector = if (isSelected) item.iconFilled else item.iconOutlined,
                                        contentDescription = item.title,
                                        tint = if (isSelected) GoldAccent else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                },
                                label = {
                                    Text(
                                        text = item.title,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) GoldRadiant else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    indicatorColor = MaterialTheme.colorScheme.primaryContainer
                                )
                            )
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentRoute) {
                "home" -> HomeScreen(
                    viewModel = viewModel,
                    onNavigate = { navigateTo(it) }
                )
                "adhkar" -> AdhkarCategoriesScreen(
                    onCategoryClick = { navigateTo("adhkar_category/$it") },
                    onSearchClick = { navigateTo("search") }
                )
                "adhkar_category_detail" -> DhikrCategoryListScreen(
                    categoryId = currentCategoryId,
                    viewModel = viewModel,
                    onBack = { popBack() },
                    onDhikrClick = { navigateTo("dhikr_detail/$it") }
                )
                "dhikr_detail" -> DhikrDetailScreen(
                    dhikrId = currentDhikrId,
                    viewModel = viewModel,
                    onBack = { popBack() }
                )
                "tasbih" -> TasbihScreen(viewModel = viewModel)
                "quran" -> QuranCatalogScreen(
                    viewModel = viewModel,
                    onSurahClick = { navigateTo("quran_reader/$it") },
                    onAudioClick = { navigateTo("audio_player/$it") }
                )
                "quran_reader" -> QuranReaderScreen(
                    surahNumber = currentSurahNumber,
                    viewModel = viewModel,
                    onBack = { popBack() },
                    onSurahChange = { currentSurahNumber = it }
                )
                "audio_player" -> AudioPlayerScreen(
                    initialSurahNumber = currentSurahNumber,
                    viewModel = viewModel,
                    onBack = { popBack() }
                )
                "prayer_times" -> PrayerTimesScreen(
                    viewModel = viewModel,
                    onNavigateToQibla = { navigateTo("qibla") },
                    onBack = { popBack() }
                )
                "qibla" -> QiblaScreen(
                    viewModel = viewModel,
                    onBack = { popBack() }
                )
                "companion" -> CompanionScreen(
                    viewModel = viewModel,
                    onNavigate = { navigateTo(it) },
                    onBack = { popBack() }
                )
                "muhasaba" -> MuhasabaScreen(
                    viewModel = viewModel,
                    onBack = { popBack() }
                )
                "wird_plan" -> WirdPlanScreen(
                    viewModel = viewModel,
                    onNavigate = { navigateTo(it) },
                    onBack = { popBack() }
                )
                "statistics" -> StatisticsScreen(
                    viewModel = viewModel,
                    onBack = { popBack() }
                )
                "favorites" -> FavoritesScreen(
                    viewModel = viewModel,
                    onBack = { popBack() }
                )
                "search" -> SearchScreen(
                    viewModel = viewModel,
                    onDhikrClick = { navigateTo("dhikr_detail/$it") },
                    onSurahClick = { navigateTo("quran_reader/$it") },
                    onBack = { popBack() }
                )
                "customization" -> CustomizationScreen(
                    viewModel = viewModel,
                    onBack = { popBack() }
                )
                "widget_guide" -> WidgetGuideScreen(
                    onBack = { popBack() }
                )
                "settings" -> SettingsScreen(
                    viewModel = viewModel,
                    onNavigateToCustomization = { navigateTo("customization") },
                    onNavigateToWidgets = { navigateTo("widget_guide") },
                    onNavigateToStats = { navigateTo("statistics") },
                    onBack = { popBack() }
                )
                else -> HomeScreen(
                    viewModel = viewModel,
                    onNavigate = { navigateTo(it) }
                )
            }
        }
    }
}
