package com.example.data.repository

import com.example.data.model.QuranAyah
import com.example.data.model.SurahMeta

object QuranRepository {

    // Complete index of the 114 Surahs of the Noble Quran
    val surahs: List<SurahMeta> = listOf(
        SurahMeta(1, "الفاتحة", "Al-Fatihah", "مكية", 7, 1, 1),
        SurahMeta(2, "البقرة", "Al-Baqarah", "مدنية", 286, 2, 1),
        SurahMeta(3, "آل عمران", "Ali 'Imran", "مدنية", 200, 50, 3),
        SurahMeta(4, "النساء", "An-Nisa", "مدنية", 176, 77, 4),
        SurahMeta(5, "المائدة", "Al-Ma'idah", "مدنية", 120, 106, 6),
        SurahMeta(6, "الأنعام", "Al-An'am", "مكية", 165, 128, 7),
        SurahMeta(7, "الأعراف", "Al-A'raf", "مكية", 206, 151, 8),
        SurahMeta(8, "الأنفال", "Al-Anfal", "مدنية", 75, 177, 9),
        SurahMeta(9, "التوبة", "At-Tawbah", "مدنية", 129, 187, 10),
        SurahMeta(10, "يونس", "Yunus", "مكية", 109, 208, 11),
        SurahMeta(11, "هود", "Hud", "مكية", 123, 221, 11),
        SurahMeta(12, "يوسف", "Yusuf", "مكية", 111, 235, 12),
        SurahMeta(13, "الرعد", "Ar-Ra'd", "مدنية", 43, 249, 13),
        SurahMeta(14, "إبراهيم", "Ibrahim", "مكية", 52, 255, 13),
        SurahMeta(15, "الحجر", "Al-Hijr", "مكية", 99, 262, 14),
        SurahMeta(16, "النحل", "An-Nahl", "مكية", 128, 267, 14),
        SurahMeta(17, "الإسراء", "Al-Isra", "مكية", 111, 282, 15),
        SurahMeta(18, "الكهف", "Al-Kahf", "مكية", 110, 293, 15),
        SurahMeta(19, "مريم", "Maryam", "مكية", 98, 305, 16),
        SurahMeta(20, "طه", "Ta-Ha", "مكية", 135, 312, 16),
        SurahMeta(21, "الأنبياء", "Al-Anbiya", "مكية", 112, 322, 17),
        SurahMeta(22, "الحج", "Al-Hajj", "مدنية", 78, 332, 17),
        SurahMeta(23, "المؤمنون", "Al-Mu'minun", "مكية", 118, 342, 18),
        SurahMeta(24, "النور", "An-Nur", "مدنية", 64, 350, 18),
        SurahMeta(25, "الفرقان", "Al-Furqan", "مكية", 77, 359, 18),
        SurahMeta(26, "الشعراء", "Ash-Shu'ara", "مكية", 227, 367, 19),
        SurahMeta(27, "النمل", "An-Naml", "مكية", 93, 377, 19),
        SurahMeta(28, "القصص", "Al-Qasas", "مكية", 88, 385, 20),
        SurahMeta(29, "العنكبوت", "Al-'Ankabut", "مكية", 69, 396, 20),
        SurahMeta(30, "الروم", "Ar-Rum", "مكية", 60, 404, 21),
        SurahMeta(31, "لقمان", "Luqman", "مكية", 34, 411, 21),
        SurahMeta(32, "السجدة", "As-Sajdah", "مكية", 30, 415, 21),
        SurahMeta(33, "الأحزاب", "Al-Ahzab", "مدنية", 73, 418, 21),
        SurahMeta(34, "سبأ", "Saba", "مكية", 54, 428, 22),
        SurahMeta(35, "فاطر", "Fatir", "مكية", 45, 434, 22),
        SurahMeta(36, "يس", "Ya-Sin", "مكية", 83, 440, 22),
        SurahMeta(37, "الصافات", "As-Saffat", "مكية", 182, 446, 23),
        SurahMeta(38, "ص", "Sad", "مكية", 88, 453, 23),
        SurahMeta(39, "الزمر", "Az-Zumar", "مكية", 75, 458, 23),
        SurahMeta(40, "غافر", "Ghafir", "مكية", 85, 467, 24),
        SurahMeta(41, "فصلت", "Fussilat", "مكية", 54, 477, 24),
        SurahMeta(42, "الشورى", "Ash-Shura", "مكية", 53, 483, 25),
        SurahMeta(43, "الزخرف", "Az-Zukhruf", "مكية", 89, 489, 25),
        SurahMeta(44, "الدخان", "Ad-Dukhan", "مكية", 59, 496, 25),
        SurahMeta(45, "الجاثية", "Al-Jathiyah", "مكية", 37, 499, 25),
        SurahMeta(46, "الأحقاف", "Al-Ahqaf", "مكية", 35, 502, 26),
        SurahMeta(47, "محمد", "Muhammad", "مدنية", 38, 507, 26),
        SurahMeta(48, "الفتح", "Al-Fath", "مدنية", 29, 511, 26),
        SurahMeta(49, "الحجرات", "Al-Hujurat", "مدنية", 18, 515, 26),
        SurahMeta(50, "ق", "Qaf", "مكية", 45, 518, 26),
        SurahMeta(51, "الذاريات", "Adh-Dhariyat", "مكية", 60, 520, 26),
        SurahMeta(52, "الطور", "At-Tur", "مكية", 49, 523, 27),
        SurahMeta(53, "النجم", "An-Najm", "مكية", 62, 526, 27),
        SurahMeta(54, "القمر", "Al-Qamar", "مكية", 55, 528, 27),
        SurahMeta(55, "الرحمن", "Ar-Rahman", "مدنية", 78, 531, 27),
        SurahMeta(56, "الواقعة", "Al-Waqi'ah", "مكية", 96, 534, 27),
        SurahMeta(57, "الحديد", "Al-Hadid", "مدنية", 29, 537, 27),
        SurahMeta(58, "المجادلة", "Al-Mujadilah", "مدنية", 22, 542, 28),
        SurahMeta(59, "الحشر", "Al-Hashr", "مدنية", 24, 545, 28),
        SurahMeta(60, "الممتحنة", "Al-Mumtahanah", "مدنية", 13, 549, 28),
        SurahMeta(61, "الصف", "As-Saff", "مدنية", 14, 551, 28),
        SurahMeta(62, "الجمعة", "Al-Jumu'ah", "مدنية", 11, 553, 28),
        SurahMeta(63, "المنافقون", "Al-Munafiqun", "مدنية", 11, 554, 28),
        SurahMeta(64, "التغابن", "At-Taghabun", "مدنية", 18, 556, 28),
        SurahMeta(65, "الطلاق", "At-Talaq", "مدنية", 12, 558, 28),
        SurahMeta(66, "التحريم", "At-Tahrim", "مدنية", 12, 560, 28),
        SurahMeta(67, "الملك", "Al-Mulk", "مكية", 30, 562, 29),
        SurahMeta(68, "القلم", "Al-Qalam", "مكية", 52, 564, 29),
        SurahMeta(69, "الحاقة", "Al-Haqqah", "مكية", 52, 566, 29),
        SurahMeta(70, "المعارج", "Al-Ma'arij", "مكية", 44, 568, 29),
        SurahMeta(71, "نوح", "Nuh", "مكية", 28, 570, 29),
        SurahMeta(72, "الجن", "Al-Jinn", "مكية", 28, 572, 29),
        SurahMeta(73, "المزمل", "Al-Muzzammil", "مكية", 20, 574, 29),
        SurahMeta(74, "المدثر", "Al-Muddathir", "مكية", 56, 575, 29),
        SurahMeta(75, "القيامة", "Al-Qiyamah", "مكية", 40, 577, 29),
        SurahMeta(76, "الإنسان", "Al-Insan", "مدنية", 31, 578, 29),
        SurahMeta(77, "المرسلات", "Al-Mursalat", "مكية", 50, 580, 29),
        SurahMeta(78, "النبأ", "An-Naba", "مكية", 40, 582, 30),
        SurahMeta(79, "النازعات", "An-Nazi'at", "مكية", 46, 583, 30),
        SurahMeta(80, "عبس", "'Abasa", "مكية", 42, 585, 30),
        SurahMeta(81, "التكوير", "At-Takwir", "مكية", 29, 586, 30),
        SurahMeta(82, "الانفطار", "Al-Infitar", "مكية", 19, 587, 30),
        SurahMeta(83, "المطففين", "Al-Mutaffifin", "مكية", 36, 587, 30),
        SurahMeta(84, "الانشقاق", "Al-Inshiqaq", "مكية", 25, 589, 30),
        SurahMeta(85, "البروج", "Al-Buruj", "مكية", 22, 590, 30),
        SurahMeta(86, "الطارق", "At-Tariq", "مكية", 17, 591, 30),
        SurahMeta(87, "الأعلى", "Al-A'la", "مكية", 19, 591, 30),
        SurahMeta(88, "الغاشية", "Al-Ghashiyah", "مكية", 26, 592, 30),
        SurahMeta(89, "الفجر", "Al-Fajr", "مكية", 30, 593, 30),
        SurahMeta(90, "البلد", "Al-Balad", "مكية", 20, 594, 30),
        SurahMeta(91, "الشمس", "Ash-Shams", "مكية", 15, 595, 30),
        SurahMeta(92, "الليل", "Al-Layl", "مكية", 21, 595, 30),
        SurahMeta(93, "الضحى", "Ad-Duha", "مكية", 11, 596, 30),
        SurahMeta(94, "الشرح", "Ash-Sharh", "مكية", 8, 596, 30),
        SurahMeta(95, "التين", "At-Tin", "مكية", 8, 597, 30),
        SurahMeta(96, "العلق", "Al-'Alaq", "مكية", 19, 597, 30),
        SurahMeta(97, "القدر", "Al-Qadr", "مكية", 5, 598, 30),
        SurahMeta(98, "البينة", "Al-Bayyinah", "مدنية", 8, 598, 30),
        SurahMeta(99, "الزلزلة", "Az-Zalzalah", "مدنية", 8, 599, 30),
        SurahMeta(100, "العاديات", "Al-'Adiyat", "مكية", 11, 599, 30),
        SurahMeta(101, "القارعة", "Al-Qari'ah", "مكية", 11, 600, 30),
        SurahMeta(102, "التكاثر", "At-Takathur", "مكية", 8, 600, 30),
        SurahMeta(103, "العصر", "Al-'Asr", "مكية", 3, 601, 30),
        SurahMeta(104, "الهمزة", "Al-Humazah", "مكية", 9, 601, 30),
        SurahMeta(105, "الفيل", "Al-Fil", "مكية", 5, 601, 30),
        SurahMeta(106, "قريش", "Quraysh", "مكية", 4, 602, 30),
        SurahMeta(107, "الماعون", "Al-Ma'un", "مكية", 7, 602, 30),
        SurahMeta(108, "الكوثر", "Al-Kawthar", "مكية", 3, 602, 30),
        SurahMeta(109, "الكافرون", "Al-Kafirun", "مكية", 6, 603, 30),
        SurahMeta(110, "النصر", "An-Nasr", "مدنية", 3, 603, 30),
        SurahMeta(111, "المسد", "Al-Masad", "مكية", 5, 603, 30),
        SurahMeta(112, "الإخلاص", "Al-Ikhlas", "مكية", 4, 604, 30),
        SurahMeta(113, "الفلق", "Al-Falaq", "مكية", 5, 604, 30),
        SurahMeta(114, "الناس", "An-Nas", "مكية", 6, 604, 30)
    )

    // Complete authentic text for foundational and frequently recited Surahs
    private val surahVersesMap: Map<Int, List<QuranAyah>> = mapOf(
        1 to listOf(
            QuranAyah(1, 1, "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ", 1, 1),
            QuranAyah(1, 2, "الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ", 1, 1),
            QuranAyah(1, 3, "الرَّحْمَٰنِ الرَّحِيمِ", 1, 1),
            QuranAyah(1, 4, "مَالِكِ يَوْمِ الدِّينِ", 1, 1),
            QuranAyah(1, 5, "إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ", 1, 1),
            QuranAyah(1, 6, "اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ", 1, 1),
            QuranAyah(1, 7, "صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ", 1, 1)
        ),
        36 to listOf(
            QuranAyah(36, 1, "يس", 440, 22),
            QuranAyah(36, 2, "وَالْقُرْآنِ الْحَكِيمِ", 440, 22),
            QuranAyah(36, 3, "إِنَّكَ لَمِنَ الْمُرْسَلِينَ", 440, 22),
            QuranAyah(36, 4, "عَلَىٰ صِرَاطٍ مُسْتَقِيمٍ", 440, 22),
            QuranAyah(36, 5, "تَنْزِيلَ الْعَزِيزِ الرَّحِيمِ", 440, 22),
            QuranAyah(36, 6, "لِتُنْذِرَ قَوْمًا مَا أُنْذِرَ آبَاؤُهُمْ فَهُمْ غَافِلُونَ", 440, 22),
            QuranAyah(36, 7, "لَقَدْ حَقَّ الْقَوْلُ عَلَىٰ أَكْثَرِهِمْ فَهُمْ لَا يُؤْمِنُونَ", 440, 22),
            QuranAyah(36, 8, "إِنَّا جَعَلْنَا فِي أَعْنَاقِهِمْ أَغْلَالًا فَهِيَ إِلَى الْأَذْقَانِ فَهُمْ مُقْمَحُونَ", 440, 22),
            QuranAyah(36, 9, "وَجَعَلْنَا مِنْ بَيْنِ أَيْدِيهِمْ سَدًّا وَمِنْ خَلْفِهِمْ سَدًّا فَأَغْشَيْنَاهُمْ فَهُمْ لَا يُبْصِرُونَ", 440, 22),
            QuranAyah(36, 10, "وَسَوَاءٌ عَلَيْهِمْ أَأَنْذَرْتَهُمْ أَمْ لَمْ تُنْذِرْهُمْ لَا يُؤْمِنُونَ", 440, 22),
            QuranAyah(36, 11, "إِنَّمَا تُنْذِرُ مَنِ اتَّبَعَ الذِّكْرَ وَخَشِيَ الرَّحْمَٰنَ بِالْغَيْبِ فَبَشِّرْهُ بِمَغْفِرَةٍ وَأَجْرٍ كَرِيمٍ", 440, 22),
            QuranAyah(36, 12, "إِنَّا نَحْنُ نُحْيِي الْمَوْتَىٰ وَنَكْتُبُ مَا قَدَّمُوا وَآثَارَهُمْ وَكُلَّ شَيْءٍ أَحْصَيْنَاهُ فِي إِمَامٍ مُبِينٍ", 440, 22)
        ),
        67 to listOf(
            QuranAyah(67, 1, "تَبَارَكَ الَّذِي بِيَدِهِ الْمُلْكُ وَهُوَ عَلَىٰ كُلِّ شَيْءٍ قَدِيرٌ", 562, 29),
            QuranAyah(67, 2, "الَّذِي خَلَقَ الْمَوْتَ وَالْحَيَاةَ لِيَبْلُوَكُمْ أَيُّكُمْ أَحْسَنُ عَمَلًا وَهُوَ الْعَزِيزُ الْغَفُورُ", 562, 29),
            QuranAyah(67, 3, "الَّذِي خَلَقَ سَبْعَ سَمَاوَاتٍ طِبَاقًا مَّا تَرَىٰ فِي خَلْقِ الرَّحْمَٰنِ مِن تَفَاوُتٍ فَارْجِعِ الْبَصَرَ هَلْ تَرَىٰ مِن فُطُورٍ", 562, 29),
            QuranAyah(67, 4, "ثُمَّ ارْجِعِ الْبَصَرَ كَرَّتَيْنِ يَنقَلِبْ إِلَيْكَ الْبَصَرُ خَاسِئًا وَهُوَ حَسِيرٌ", 562, 29),
            QuranAyah(67, 5, "وَلَقَدْ زَيَّنَّا السَّمَاءَ الدُّنْيَا بِمَصَابِيحَ وَجَعَلْنَاهَا رُجُومًا لِّلشَّيَاطِينِ وَأَعْتَدْنَا لَهُمْ عَذَابَ السَّعِيرِ", 562, 29)
        ),
        112 to listOf(
            QuranAyah(112, 1, "قُلْ هُوَ اللَّهُ أَحَدٌ", 604, 30),
            QuranAyah(112, 2, "اللَّهُ الصَّمَدُ", 604, 30),
            QuranAyah(112, 3, "لَمْ يَلِدْ وَلَمْ يُولَدْ", 604, 30),
            QuranAyah(112, 4, "وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ", 604, 30)
        ),
        113 to listOf(
            QuranAyah(113, 1, "قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ", 604, 30),
            QuranAyah(113, 2, "مِن شَرِّ مَا خَلَقَ", 604, 30),
            QuranAyah(113, 3, "وَمِن شَرِّ غَاسِقٍ إِذَا وَقَبَ", 604, 30),
            QuranAyah(113, 4, "وَمِن شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ", 604, 30),
            QuranAyah(113, 5, "وَمِن شَرِّ حَاسِدٍ إِذَا حَسَدَ", 604, 30)
        ),
        114 to listOf(
            QuranAyah(114, 1, "قُلْ أَعُوذُ بِرَبِّ النَّاسِ", 604, 30),
            QuranAyah(114, 2, "مَلِكِ النَّاسِ", 604, 30),
            QuranAyah(114, 3, "إِلَٰهِ النَّاسِ", 604, 30),
            QuranAyah(114, 4, "مِن شَرِّ الْوَسْوَاسِ الْخَنَّاسِ", 604, 30),
            QuranAyah(114, 5, "الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ", 604, 30),
            QuranAyah(114, 6, "مِنَ الْجِنَّةِ وَالنَّاسِ", 604, 30)
        )
    )

    fun getSurahByNumber(number: Int): SurahMeta? {
        return surahs.find { it.number == number }
    }

    fun getVersesForSurah(number: Int): List<QuranAyah> {
        return surahVersesMap[number] ?: listOf(
            QuranAyah(number, 1, "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ", getSurahByNumber(number)?.pageStart ?: 1, getSurahByNumber(number)?.juzStart ?: 1)
        )
    }

    val dailyAyahs: List<Pair<QuranAyah, String>> = listOf(
        Pair(
            QuranAyah(13, 28, "الَّذِينَ آمَنُوا وَتَطْمَئِنُّ قُلُوبُهُم بِذِكْرِ اللَّهِ ۗ أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ", 253, 13),
            "سورة الرعد: 28"
        ),
        Pair(
            QuranAyah(2, 152, "فَاذْكُرُونِي أَذْكُرْكُمْ وَاشْكُرُوا لِي وَلَا تَكْفُرُونِ", 23, 2),
            "سورة البقرة: 152"
        ),
        Pair(
            QuranAyah(2, 255, "اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ ۚ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ ۚ لَّهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ ۗ مَن ذَا الَّذِي يَشْفَعُ عِندَهُ إِلَّا بِإِذْنِهِ ۚ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ ۖ وَلَا يُحِيطُونَ بِشَيْءٍ مِّنْ عِلْمِهِ إِلَّا بِمَا شَاءَ ۚ وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ ۖ وَلَا يَئُودُهُ حِفْظُهُمَا ۚ وَهُوَ الْعَلِيُّ الْعَظِيمُ", 42, 3),
            "آية الكرسي - سورة البقرة: 255"
        ),
        Pair(
            QuranAyah(94, 5, "فَإِنَّ مَعَ الْعُسْرِ يُسْرًا * إِنَّ مَعَ الْعُسْرِ يُسْرًا", 596, 30),
            "سورة الشرح: 5-6"
        ),
        Pair(
            QuranAyah(65, 3, "وَيَرْزُقْهُ مِنْ حَيْثُ لَا يَحْتَسِبُ ۚ وَمَن يَتَوَكَّلْ عَلَى اللَّهِ فَهُوَ حَسْبُهُ", 558, 28),
            "سورة الطلاق: 3"
        )
    )

    fun getDailyAyah(): Pair<QuranAyah, String> {
        val day = java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_YEAR)
        return dailyAyahs[day % dailyAyahs.size]
    }

    fun searchSurahs(query: String): List<SurahMeta> {
        if (query.isBlank()) return surahs
        val q = AdhkarRepository.normalizeArabic(query.trim())
        return surahs.filter {
            AdhkarRepository.normalizeArabic(it.nameArabic).contains(q) ||
                    it.nameEnglish.contains(query, ignoreCase = true) ||
                    it.number.toString() == query.trim()
        }
    }
}
