package com.example.data.repository

import com.example.data.model.DailyPrayerTimes
import com.example.data.model.PrayerTimeItem
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin
import kotlin.math.tan

data class CityLocation(
    val nameArabic: String,
    val countryArabic: String,
    val latitude: Double,
    val longitude: Double,
    val timeZoneId: String
)

object PrayerTimesCalculator {

    val popularCities: List<CityLocation> = listOf(
        CityLocation("مكة المكرمة", "المملكة العربية السعودية", 21.4225, 39.8262, "Asia/Riyadh"),
        CityLocation("المدينة المنورة", "المملكة العربية السعودية", 24.5247, 39.5692, "Asia/Riyadh"),
        CityLocation("الرياض", "المملكة العربية السعودية", 24.7136, 46.6753, "Asia/Riyadh"),
        CityLocation("جدة", "المملكة العربية السعودية", 21.5433, 39.1728, "Asia/Riyadh"),
        CityLocation("القاهرة", "مصر", 30.0444, 31.2357, "Africa/Cairo"),
        CityLocation("الإسكندرية", "مصر", 31.2001, 29.9187, "Africa/Cairo"),
        CityLocation("القدس الشريف", "فلسطين", 31.7683, 35.2137, "Asia/Jerusalem"),
        CityLocation("عمان", "الأردن", 31.9454, 35.9284, "Asia/Amman"),
        CityLocation("دبي", "الإمارات العربية المتحدة", 25.2048, 55.2708, "Asia/Dubai"),
        CityLocation("أبو ظبي", "الإمارات العربية المتحدة", 24.4539, 54.3773, "Asia/Dubai"),
        CityLocation("الدوحة", "قطر", 25.2854, 51.5310, "Asia/Qatar"),
        CityLocation("الكويت", "الكويت", 29.3759, 47.9774, "Asia/Kuwait"),
        CityLocation("المنامة", "البحرين", 26.2285, 50.5860, "Asia/Bahrain"),
        CityLocation("مسقط", "عُمان", 23.5859, 58.4059, "Asia/Muscat"),
        CityLocation("بغداد", "العراق", 33.3152, 44.3661, "Asia/Baghdad"),
        CityLocation("دمشق", "سوريا", 33.5138, 36.2765, "Asia/Damascus"),
        CityLocation("بيروت", "لبنان", 33.8938, 35.5018, "Asia/Beirut"),
        CityLocation("الرباط", "المغرب", 34.0209, -6.8416, "Africa/Casablanca"),
        CityLocation("الجزائر", "الجزائر", 36.7538, 3.0588, "Africa/Algiers"),
        CityLocation("تونس", "تونس", 36.8065, 10.1815, "Africa/Tunis"),
        CityLocation("إسطنبول", "تركيا", 41.0082, 28.9784, "Europe/Istanbul"),
        CityLocation("لندن", "المملكة المتحدة", 51.5074, -0.1278, "Europe/London")
    )

    // Accurate calculation of prayer times using standard solar astronomical formula
    fun calculatePrayerTimes(
        latitude: Double,
        longitude: Double,
        calendar: Calendar = Calendar.getInstance()
    ): DailyPrayerTimes {
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH) + 1
        val day = calendar.get(Calendar.DAY_OF_MONTH)
        val timeZone = calendar.timeZone.rawOffset / (1000.0 * 3600.0)

        // Julian Date
        val a = floor((14 - month) / 12.0)
        val y = year + 4800 - a
        val m = month + 12 * a - 3
        val jd = day + floor((153 * m + 2) / 5.0) + 365 * y + floor(y / 4.0) - floor(y / 100.0) + floor(y / 400.0) - 32045

        val d = jd - 2451545.0
        val g = fixAngle(357.529 + 0.98560028 * d)
        val q = fixAngle(280.459 + 0.98564736 * d)
        val l = fixAngle(q + 1.915 * sin(Math.toRadians(g)) + 0.020 * sin(Math.toRadians(2 * g)))

        val e = 23.439 - 0.00000036 * d
        val ra = Math.toDegrees(atan2(cos(Math.toRadians(e)) * sin(Math.toRadians(l)), cos(Math.toRadians(l)))) / 15.0
        val delta = Math.toDegrees(asin(sin(Math.toRadians(e)) * sin(Math.toRadians(l))))
        val eqt = q / 15.0 - fixHour(ra)

        // Dhuhr (solar noon)
        val noon = fixHour(12.0 + timeZone - longitude / 15.0 - eqt)

        // Sun angles: Fajr 18.5 deg, Isha 18.5 deg
        val fajrAngle = 18.5
        val ishaAngle = 18.5

        val fajrDiff = sunAngleDiff(latitude, delta, -fajrAngle)
        val sunriseDiff = sunAngleDiff(latitude, delta, -0.8333)
        val asrDiff = asrAngleDiff(latitude, delta)
        val sunsetDiff = sunAngleDiff(latitude, delta, -0.8333)
        val ishaDiff = sunAngleDiff(latitude, delta, -ishaAngle)

        val fajrTime = fixHour(noon - fajrDiff)
        val sunriseTime = fixHour(noon - sunriseDiff)
        val dhuhrTime = noon
        val asrTime = fixHour(noon + asrDiff)
        val maghribTime = fixHour(noon + sunsetDiff)
        val ishaTime = fixHour(noon + ishaDiff)

        val fajrStr = formatHourToAmPm(fajrTime)
        val sunriseStr = formatHourToAmPm(sunriseTime)
        val dhuhrStr = formatHourToAmPm(dhuhrTime)
        val asrStr = formatHourToAmPm(asrTime)
        val maghribStr = formatHourToAmPm(maghribTime)
        val ishaStr = formatHourToAmPm(ishaTime)

        val currentHourDecimal = calendar.get(Calendar.HOUR_OF_DAY) + calendar.get(Calendar.MINUTE) / 60.0

        val (nextName, minutesLeft) = determineNextPrayer(
            currentHourDecimal,
            fajrTime,
            dhuhrTime,
            asrTime,
            maghribTime,
            ishaTime
        )

        val sdfGregorian = SimpleDateFormat("EEEE، d MMMM yyyy", Locale("ar"))
        val dateGregorian = sdfGregorian.format(calendar.time)

        // Approximate Hijri representation
        val hijriDate = calculateApproximateHijri(calendar)

        return DailyPrayerTimes(
            fajr = fajrStr,
            sunrise = sunriseStr,
            dhuhr = dhuhrStr,
            asr = asrStr,
            maghrib = maghribStr,
            isha = ishaStr,
            nextPrayerName = nextName,
            minutesRemaining = minutesLeft,
            dateHijri = hijriDate,
            dateGregorian = dateGregorian
        )
    }

    private fun sunAngleDiff(latitude: Double, delta: Double, angle: Double): Double {
        val cosHour = (sin(Math.toRadians(angle)) - sin(Math.toRadians(latitude)) * sin(Math.toRadians(delta))) /
                (cos(Math.toRadians(latitude)) * cos(Math.toRadians(delta)))
        val clamped = cosHour.coerceIn(-1.0, 1.0)
        return Math.toDegrees(acos(clamped)) / 15.0
    }

    private fun asrAngleDiff(latitude: Double, delta: Double): Double {
        val angle = -Math.toDegrees(atan(1.0 + tan(Math.toRadians(abs(latitude - delta)))))
        return sunAngleDiff(latitude, delta, angle)
    }

    private fun fixAngle(a: Double): Double {
        var res = a - 360.0 * floor(a / 360.0)
        if (res < 0) res += 360.0
        return res
    }

    private fun fixHour(h: Double): Double {
        var res = h - 24.0 * floor(h / 24.0)
        if (res < 0) res += 24.0
        return res
    }

    private fun formatHourToAmPm(hourDecimal: Double): String {
        val totalMinutes = (hourDecimal * 60).toInt() % (24 * 60)
        var hours = totalMinutes / 60
        val mins = totalMinutes % 60
        val amPm = if (hours >= 12) "م" else "ص"
        if (hours > 12) hours -= 12
        if (hours == 0) hours = 12
        return String.format(Locale("ar"), "%02d:%02d %s", hours, mins, amPm)
    }

    private fun determineNextPrayer(
        nowHour: Double,
        fajr: Double,
        dhuhr: Double,
        asr: Double,
        maghrib: Double,
        isha: Double
    ): Pair<String, Int> {
        val prayers = listOf(
            Pair("الفجر", fajr),
            Pair("الظهر", dhuhr),
            Pair("العصر", asr),
            Pair("المغرب", maghrib),
            Pair("العشاء", isha)
        )

        for (p in prayers) {
            if (p.second > nowHour) {
                val diffHours = p.second - nowHour
                return Pair(p.first, (diffHours * 60).toInt())
            }
        }

        // After Isha -> Next is tomorrow Fajr
        val diffHours = (24.0 - nowHour) + fajr
        return Pair("الفجر", (diffHours * 60).toInt())
    }

    // Hijri date calculation
    fun calculateApproximateHijri(calendar: Calendar): String {
        val cal = Calendar.getInstance()
        cal.time = calendar.time
        val jd = cal.get(Calendar.DAY_OF_YEAR)
        val hijriMonths = listOf(
            "محرم", "صفر", "ربيع الأول", "ربيع الآخر", "جمادى الأولى", "جمادى الآخرة",
            "رجب", "شعبان", "رمضان", "شوال", "ذو القعدة", "ذو الحجة"
        )
        // Reference point: 1446-1447 AH
        val hijriYear = 1448
        val hijriMonthIndex = (jd / 30).coerceIn(0, 11)
        val hijriDay = ((jd % 30) + 1).coerceIn(1, 30)
        return "$hijriDay ${hijriMonths[hijriMonthIndex]} $hijriYear هـ"
    }

    // Qibla direction towards the Kaaba (21.4225° N, 39.8262° E)
    fun calculateQiblaBearing(latitude: Double, longitude: Double): Double {
        val kaabaLat = Math.toRadians(21.4225)
        val kaabaLng = Math.toRadians(39.8262)
        val userLat = Math.toRadians(latitude)
        val userLng = Math.toRadians(longitude)

        val deltaLng = kaabaLng - userLng
        val y = sin(deltaLng) * cos(kaabaLat)
        val x = cos(userLat) * sin(kaabaLat) - sin(userLat) * cos(kaabaLat) * cos(deltaLng)

        var bearing = Math.toDegrees(atan2(y, x))
        if (bearing < 0) bearing += 360.0
        return bearing
    }
}
