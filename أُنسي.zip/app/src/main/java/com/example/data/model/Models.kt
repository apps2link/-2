package com.example.data.model

data class DhikrItem(
    val id: String,
    val categoryId: String,
    val categoryArabic: String,
    val textArabic: String,
    val fadilah: String,
    val reference: String,
    val repeatTarget: Int = 1,
    val audioUrl: String? = null
)

data class DhikrCategory(
    val id: String,
    val titleArabic: String,
    val count: Int,
    val descriptionArabic: String
)

data class SurahMeta(
    val number: Int,
    val nameArabic: String,
    val nameEnglish: String,
    val revelationType: String, // "مكية" or "مدنية"
    val versesCount: Int,
    val pageStart: Int,
    val juzStart: Int
)

data class QuranAyah(
    val surahNumber: Int,
    val ayahNumber: Int,
    val textArabic: String,
    val page: Int,
    val juz: Int
)

data class PrayerTimeItem(
    val nameArabic: String,
    val timeFormatted: String,
    val isNext: Boolean = false,
    val isPassed: Boolean = false,
    val isDone: Boolean = false
)

data class DailyPrayerTimes(
    val fajr: String,
    val sunrise: String,
    val dhuhr: String,
    val asr: String,
    val maghrib: String,
    val isha: String,
    val nextPrayerName: String,
    val minutesRemaining: Int,
    val dateHijri: String,
    val dateGregorian: String
)

data class CompanionRecommendation(
    val id: String,
    val titleArabic: String,
    val messageArabic: String,
    val sourceOrFadilah: String,
    val actionLabel: String,
    val actionRoute: String
)

data class CompanionChatMessage(
    val id: String,
    val isFromCompanion: Boolean,
    val text: String,
    val actionButtonText: String? = null,
    val actionRoute: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)
