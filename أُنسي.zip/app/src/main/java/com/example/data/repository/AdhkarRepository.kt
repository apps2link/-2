package com.example.data.repository

import com.example.data.model.DhikrCategory
import com.example.data.model.DhikrItem

object AdhkarRepository {

    val categories: List<DhikrCategory> = listOf(
        DhikrCategory("sabah", "أذكار الصباح", 12, "أذكار حفظ النفس والبركة من بزوغ الفجر حتى الشروق"),
        DhikrCategory("masaa", "أذكار المساء", 12, "أذكار الحفظ والطمأنينة من العصر حتى مغيب الشمس"),
        DhikrCategory("sleep", "أذكار النوم", 6, "سنن وأذكار ما قبل النوم وسكينة الروح"),
        DhikrCategory("wake", "أذكار الاستيقاظ", 4, "أذكار بدء اليوم بحمد الله وشكره"),
        DhikrCategory("post_prayer", "أذكار بعد الصلاة", 8, "التسبيح والتحميد والاستغفار عقب الصلوات المفروضة"),
        DhikrCategory("prayer", "أذكار الصلاة", 5, "أدعية الاستفتاح والركوع والسجود والتشهد"),
        DhikrCategory("home", "أذكار المنزل", 4, "أذكار الخروج من المنزل والدخول إليه"),
        DhikrCategory("mosque", "أذكار المسجد", 4, "دعاء الذهاب إلى المسجد ودخول المسجد والخروج منه"),
        DhikrCategory("food", "أذكار الطعام والشراب", 3, "التسمية والحمد وسنن المأكل والمشرب"),
        DhikrCategory("travel", "أذكار السفر", 4, "دعاء ركوب الدابة ودعاء السفر وتوديع المسافر"),
        DhikrCategory("distress", "أدعية الكرب والهم", 6, "دعاء ذي النون وتفريج الهموم والسكينة في الشدائد"),
        DhikrCategory("istighfar", "الاستغفار والتوبة", 6, "سيد الاستغفار وأدعية محو الذنوب وصلاح القلب"),
        DhikrCategory("ruqyah", "الرقية الشرعية", 6, "الآيات والأدعية النبوية الثابتة للشفاء والتحصين"),
        DhikrCategory("general", "الأذكار العامة", 8, "الباقيات الصالحات وكنوز الجنة المطلقة في كل وقت"),
        DhikrCategory("quranic_dua", "الأدعية القرآنية", 8, "جوامع الدعاء من كتاب الله تعالى")
    )

    private val allDhikrList: List<DhikrItem> = listOf(
        // === أذكار الصباح ===
        DhikrItem(
            id = "sabah_1",
            categoryId = "sabah",
            categoryArabic = "أذكار الصباح",
            textArabic = "أَصْبَحْنَا وَأَصْبَحَ المُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لا إِلَهَ إِلا اللَّهُ وَحْدَهُ لا شَرِيكَ لَهُ، لَهُ المُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ، رَبِّ أَسْأَلُكَ خَيْرَ مَا فِي هَذَا الْيَوْمِ وَخَيْرَ مَا بَعْدَهُ، وَأَعُوذُ بِكَ مِنْ شَرِّ مَا فِي هَذَا الْيَوْمِ وَشَرِّ مَا بَعْدَهُ.",
            fadilah = "بداية اليوم بتوحيد الله والاعتصام به وطلب خير اليوم كله والتعوذ من الشرور.",
            reference = "صحيح مسلم (2723)",
            repeatTarget = 1
        ),
        DhikrItem(
            id = "sabah_2",
            categoryId = "sabah",
            categoryArabic = "أذكار الصباح",
            textArabic = "اللَّهُمَّ أَنْتَ رَبِّي لا إِلَهَ إِلا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ، وَأَبُوءُ بِذَنْبِي فَاغْفِرْ لِي فَإِنَّهُ لا يَغْفِرُ الذُّنُوبَ إِلا أَنْتَ.",
            fadilah = "سيد الاستغفار؛ من قالها موقناً بها حين يصبح فمات من يومه دخل الجنة.",
            reference = "صحيح البخاري (6306)",
            repeatTarget = 1
        ),
        DhikrItem(
            id = "sabah_3",
            categoryId = "sabah",
            categoryArabic = "أذكار الصباح",
            textArabic = "بِسْمِ اللَّهِ الَّذِي لا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الأَرْضِ وَلا فِي السَّمَاءِ وَهُوَ السَّمِيعُ العَلِيمُ.",
            fadilah = "من قالها ثلاثاً إذا أصبح وثلاثاً إذا أمسى لم يضره شيء.",
            reference = "سنن أبي داود (5088) والترمذي، صحيح",
            repeatTarget = 3
        ),
        DhikrItem(
            id = "sabah_4",
            categoryId = "sabah",
            categoryArabic = "أذكار الصباح",
            textArabic = "رَضِيتُ بِاللَّهِ رَبًّا، وَبِالإِسْلامِ دِينًا، وَبِمُحَمَّدٍ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ نَبِيًّا.",
            fadilah = "من قالها حين يصبح وحين يمسي كان حقاً على الله أن يرضيه يوم القيامة.",
            reference = "سنن الترمذي (3389) وأبو داود، حسن",
            repeatTarget = 3
        ),
        DhikrItem(
            id = "sabah_5",
            categoryId = "sabah",
            categoryArabic = "أذكار الصباح",
            textArabic = "يَا حَيُّ يَا قَيُّومُ بِرَحْمَتِكَ أَسْتَغِيثُ، أَصْلِحْ لِي شَأْنِي كُلَّهُ، وَلا تَكِلْنِي إِلَى نَفْسِي طَرْفَةَ عَيْنٍ.",
            fadilah = "دعاء النجاة وتفويض الأمر كله إلى الله وتبرؤ العبد من حوله وقوته.",
            reference = "المستدرك للحاكم والنسائي، صحيح",
            repeatTarget = 1
        ),
        DhikrItem(
            id = "sabah_6",
            categoryId = "sabah",
            categoryArabic = "أذكار الصباح",
            textArabic = "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ: عَدَدَ خَلْقِهِ، وَرِضَا نَفْسِهِ، وَزِنَةَ عَرْشِهِ، وَمِدَادَ كَلِمَاتِهِ.",
            fadilah = "تزن في الأجر ما يسبحه الذاكر ساعات طويلة من فضائل التسبيح المضاعف.",
            reference = "صحيح مسلم (2726)",
            repeatTarget = 3
        ),
        DhikrItem(
            id = "sabah_7",
            categoryId = "sabah",
            categoryArabic = "أذكار الصباح",
            textArabic = "اللَّهُمَّ عَافِنِي فِي بَدَنِي، اللَّهُمَّ عَافِنِي فِي سَمْعِي، اللَّهُمَّ عَافِنِي فِي بَصَرِي، لا إِلَهَ إِلا أَنْتَ. اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الكُفْرِ وَالفَقْرِ، وَأَعُوذُ بِكَ مِنْ عَذَابِ القَبْرِ، لا إِلَهَ إِلا أَنْتَ.",
            fadilah = "سؤال الله السلامة التامة في الجوارح والأبدان والدين.",
            reference = "سنن أبي داود (5090)، حسن",
            repeatTarget = 3
        ),
        DhikrItem(
            id = "sabah_8",
            categoryId = "sabah",
            categoryArabic = "أذكار الصباح",
            textArabic = "حَسْبِيَ اللَّهُ لا إِلَهَ إِلا هُوَ عَلَيْهِ تَوَكَّلْتُ وَهُوَ رَبُّ العَرْشِ العَظِيمِ.",
            fadilah = "من قالها حين يصبح وحين يمسي سبع مرات كفاه الله ما أهمه من أمر الدنيا والآخرة.",
            reference = "سنن أبي داود (5081) بسند صحيح موقوفاً",
            repeatTarget = 7
        ),

        // === أذكار المساء ===
        DhikrItem(
            id = "masaa_1",
            categoryId = "masaa",
            categoryArabic = "أذكار المساء",
            textArabic = "أَمْسَيْنَا وَأَمْسَى المُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لا إِلَهَ إِلا اللَّهُ وَحْدَهُ لا شَرِيكَ لَهُ، لَهُ المُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ، رَبِّ أَسْأَلُكَ خَيْرَ مَا فِي هَذِهِ اللَّيْلَةِ وَخَيْرَ مَا بَعْدَهَا، وَأَعُوذُ بِكَ مِنْ شَرِّ مَا فِي هَذِهِ اللَّيْلَةِ وَشَرِّ مَا بَعْدَهَا.",
            fadilah = "تحصين الليلة وسؤال خيرها والاستعاذة من الكسل وسوء الكبر وعذاب النار.",
            reference = "صحيح مسلم (2723)",
            repeatTarget = 1
        ),
        DhikrItem(
            id = "masaa_2",
            categoryId = "masaa",
            categoryArabic = "أذكار المساء",
            textArabic = "أَعُوذُ بِكَلِمَاتِ اللَّهِ التَّامَّاتِ مِنْ شَرِّ مَا خَلَقَ.",
            fadilah = "من قالها حين يمسي ثلاث مرات لم يضره حُمَةٌ ولا لدغة في تلك الليلة.",
            reference = "صحيح مسلم (2709)",
            repeatTarget = 3
        ),
        DhikrItem(
            id = "masaa_3",
            categoryId = "masaa",
            categoryArabic = "أذكار المساء",
            textArabic = "اللَّهُمَّ بِكَ أَمْسَيْنَا، وَبِكَ أَصْبَحْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ الْمَصِيرُ.",
            fadilah = "استشعار معية الله وتصريف الأوقات والحياة والموت بيده سبحانه.",
            reference = "سنن الترمذي (3391)، صحيح",
            repeatTarget = 1
        ),

        // === أذكار بعد الصلاة ===
        DhikrItem(
            id = "post_1",
            categoryId = "post_prayer",
            categoryArabic = "أذكار بعد الصلاة",
            textArabic = "أَسْتَغْفِرُ اللَّهَ، أَسْتَغْفِرُ اللَّهَ، أَسْتَغْفِرُ اللَّهَ. اللَّهُمَّ أَنْتَ السَّلامُ وَمِنْكَ السَّلامُ، تَبَارَكْتَ يَا ذَا الجَلالِ وَالإِكْرَامِ.",
            fadilah = "السنة الثابتة عن النبي ﷺ فور السلام من الصلاة المكتوبة.",
            reference = "صحيح مسلم (591)",
            repeatTarget = 1
        ),
        DhikrItem(
            id = "post_2",
            categoryId = "post_prayer",
            categoryArabic = "أذكار بعد الصلاة",
            textArabic = "لا إِلَهَ إِلا اللَّهُ وَحْدَهُ لا شَرِيكَ لَهُ، لَهُ المُلْكُ وَلَهُ الحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ، لا حَوْلَ وَلا قُوَّةَ إِلا بِاللَّهِ، لا إِلَهَ إِلا اللَّهُ، وَلا نَعْبُدُ إِلا إِيَّاهُ، لَهُ النِّعْمَةُ وَلَهُ الفَضْلُ وَلَهُ الثَّنَاءُ الحَسَنُ.",
            fadilah = "تعظيم الله وتهليله ونفي الحول والقوة إلا به سبحانه.",
            reference = "صحيح مسلم (594)",
            repeatTarget = 1
        ),
        DhikrItem(
            id = "post_3",
            categoryId = "post_prayer",
            categoryArabic = "أذكار بعد الصلاة",
            textArabic = "سُبْحَانَ اللَّهِ (33) ، الحَمْدُ لِلَّهِ (33) ، اللَّهُ أَكْبَرُ (33) ، وَتَمَامُ الْمِائَةِ: لا إِلَهَ إِلا اللَّهُ وَحْدَهُ لا شَرِيكَ لَهُ، لَهُ المُلْكُ وَلَهُ الحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ.",
            fadilah = "غُفِرَتْ خَطَايَاهُ وَإِنْ كَانَتْ مِثْلَ زَبَدِ البَحْرِ.",
            reference = "صحيح مسلم (597)",
            repeatTarget = 100
        ),
        DhikrItem(
            id = "post_4",
            categoryId = "post_prayer",
            categoryArabic = "أذكار بعد الصلاة",
            textArabic = "اللَّهُمَّ أَعِنِّي عَلَى ذِكْرِكَ، وَشُكْرِكَ، وَحُسْنِ عِبَادَتِكَ.",
            fadilah = "وصية النبي ﷺ لمعاذ بن جبل ألا يدعها دبر كل صلاة.",
            reference = "سنن أبي داود (1522)، صحيح",
            repeatTarget = 1
        ),

        // === أذكار النوم ===
        DhikrItem(
            id = "sleep_1",
            categoryId = "sleep",
            categoryArabic = "أذكار النوم",
            textArabic = "بِاسْمِكَ رَبِّي وَضَعْتُ جَنْبِي، وَبِكَ أَرْفَعُهُ، فَإِنْ أَمْسَكْتَ نَفْسِي فَارْحَمْهَا، وَإِنْ أَرْسَلْتَهَا فَاحْفَظْهَا بِمَا تَحْفَظُ بِهِ عِبَادَكَ الصَّالِحِينَ.",
            fadilah = "حفظ الروح عند النوم والتسليم التام لأمر الله.",
            reference = "صحيح البخاري (6320) ومسلم",
            repeatTarget = 1
        ),
        DhikrItem(
            id = "sleep_2",
            categoryId = "sleep",
            categoryArabic = "أذكار النوم",
            textArabic = "اللَّهُمَّ قِنِي عَذَابَكَ يَوْمَ تَبْعَثُ عِبَادَكَ.",
            fadilah = "كان النبي ﷺ إذا أراد أن يرقد وضع يده تحت خده الأيمن ثم قالها ثلاث مرات.",
            reference = "سنن أبي داود (5045) والترمذي، صحيح",
            repeatTarget = 3
        ),

        // === أدعية الكرب والهم ===
        DhikrItem(
            id = "distress_1",
            categoryId = "distress",
            categoryArabic = "أدعية الكرب والهم",
            textArabic = "لا إِلَهَ إِلا أَنْتَ سُبْحَانَكَ إِنِّي كُنْتُ مِنَ الظَّالِمِينَ.",
            fadilah = "دعوة ذي النون في بطن الحوت؛ لم يدعُ بها رجل مسلم في شيء قط إلا استجاب الله له.",
            reference = "سنن الترمذي (3505)، صحيح",
            repeatTarget = 1
        ),
        DhikrItem(
            id = "distress_2",
            categoryId = "distress",
            categoryArabic = "أدعية الكرب والهم",
            textArabic = "اللَّهُمَّ إِنِّي عَبْدُكَ، ابْنُ عَبْدِكَ، ابْنُ أَمَتِكَ، نَاصِيَتِي بِيَدِكَ، مَاضٍ فِيَّ حُكْمُكَ، عَدْلٌ فِيَّ قَضَاؤُكَ، أَسْأَلُكَ بِكُلِّ اسْمٍ هُوَ لَكَ سَمَّيْتَ بِهِ نَفْسَكَ، أَوْ أَنْزَلْتَهُ فِي كِتَابِكَ، أَوْ عَلَّمْتَهُ أَحَدًا مِنْ خَلْقِكَ، أَوِ اسْتَأْثَرْتَ بِهِ فِي عِلْمِ الغَيْبِ عِنْدَكَ: أَنْ تَجْعَلَ القُرْآنَ رَبِيعَ قَلْبِي، وَنُورَ صَدْرِي، وَجَلاءَ حُزْنِي، وَذَهَابَ هَمِّي.",
            fadilah = "ما أصاب أحداً قط هم ولا حزن فقالها إلا أذهب الله همه وحزنه وأبدله مكانه فرجاً.",
            reference = "مسند أحمد (3712)، صحيح",
            repeatTarget = 1
        ),

        // === الأذكار العامة ===
        DhikrItem(
            id = "gen_1",
            categoryId = "general",
            categoryArabic = "الأذكار العامة",
            textArabic = "سُبْحَانَ اللَّهِ، وَالْحَمْدُ لِلَّهِ، وَلا إِلَهَ إِلا اللَّهُ، وَاللَّهُ أَكْبَرُ.",
            fadilah = "أحب الكلام إلى الله تعالى، وهن الباقيات الصالحات وغراس الجنة.",
            reference = "صحيح مسلم (2137)",
            repeatTarget = 100
        ),
        DhikrItem(
            id = "gen_2",
            categoryId = "general",
            categoryArabic = "الأذكار العامة",
            textArabic = "لا حَوْلَ وَلا قُوَّةَ إِلا بِاللَّهِ العَلِيِّ العَظِيمِ.",
            fadilah = "كنز من كنوز الجنة وباب من أبوابها ودواء لتسعة وتسعين داء أيسرها الهم.",
            reference = "صحيح البخاري (4205) ومسلم",
            repeatTarget = 100
        ),
        DhikrItem(
            id = "gen_3",
            categoryId = "general",
            categoryArabic = "الأذكار العامة",
            textArabic = "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ، سُبْحَانَ اللَّهِ العَظِيمِ.",
            fadilah = "كلمتان خفيفتان على اللسان، ثقيلتان في الميزان، حبيبتان إلى الرحمن.",
            reference = "صحيح البخاري (6682) ومسلم",
            repeatTarget = 100
        ),
        DhikrItem(
            id = "gen_4",
            categoryId = "general",
            categoryArabic = "الأذكار العامة",
            textArabic = "اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ.",
            fadilah = "من صلى عليّ صلاة واحدة صلى الله عليه بها عشراً وحط عنه بها عشر خطيئات.",
            reference = "سنن النسائي (1297)، صحيح",
            repeatTarget = 100
        ),

        // === الأدعية القرآنية ===
        DhikrItem(
            id = "quran_1",
            categoryId = "quranic_dua",
            categoryArabic = "الأدعية القرآنية",
            textArabic = "﴿ رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ ﴾",
            fadilah = "كان أكثر دعاء النبي ﷺ لما تجمع من خيري الدنيا والآخرة والسلامة من النار.",
            reference = "سورة البقرة: 201 (صحيح البخاري 6389)",
            repeatTarget = 1
        ),
        DhikrItem(
            id = "quran_2",
            categoryId = "quranic_dua",
            categoryArabic = "الأدعية القرآنية",
            textArabic = "﴿ رَبِّ اشْرَحْ لِي صَدْرِي * وَيَسِّرْ لِي أَمْرِي * وَاحْلُلْ عُقْدَةً مِّن لِّسَانِي * يَفْقَهُوا قَوْلِي ﴾",
            fadilah = "دعاء نبي الله موسى عليه السلام لانشراح الصدر وتيسير الأمور والفصاحة.",
            reference = "سورة طه: 25-28",
            repeatTarget = 1
        ),
        DhikrItem(
            id = "quran_3",
            categoryId = "quranic_dua",
            categoryArabic = "الأدعية القرآنية",
            textArabic = "﴿ رَبَّنَا لا تُزِغْ قُلُوبَنَا بَعْدَ إِذْ هَدَيْتَنَا وَهَبْ لَنَا مِن لَّدُنكَ رَحْمَةً إِنَّكَ أَنتَ الْوَهَّابُ ﴾",
            fadilah = "دعاء الراسخين في العلم للثبات على الهدى ونيل رحمة الله الواسعة.",
            reference = "سورة آل عمران: 8",
            repeatTarget = 1
        )
    )

    fun getDhikrByCategory(categoryId: String): List<DhikrItem> {
        return allDhikrList.filter { it.categoryId == categoryId }
    }

    fun getDhikrById(id: String): DhikrItem? {
        return allDhikrList.find { it.id == id }
    }

    fun getDailyDhikr(): DhikrItem {
        val dayOfYear = java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_YEAR)
        val index = dayOfYear % allDhikrList.size
        return allDhikrList[index]
    }

    fun searchDhikr(query: String): List<DhikrItem> {
        if (query.isBlank()) return emptyList()
        val normalizedQuery = normalizeArabic(query.trim())
        return allDhikrList.filter { item ->
            normalizeArabic(item.textArabic).contains(normalizedQuery) ||
                    normalizeArabic(item.categoryArabic).contains(normalizedQuery) ||
                    normalizeArabic(item.fadilah).contains(normalizedQuery) ||
                    normalizeArabic(item.reference).contains(normalizedQuery)
        }
    }

    fun normalizeArabic(text: String): String {
        return text
            .replace(Regex("[\\u064B-\\u065F\\u0670]"), "") // remove tashkeel
            .replace('أ', 'ا')
            .replace('إ', 'ا')
            .replace('آ', 'ا')
            .replace('ة', 'ه')
            .replace('ى', 'ي')
    }
}
