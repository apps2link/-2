package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.local.entity.DhikrProgressEntity
import com.example.data.local.entity.FavoriteEntity
import com.example.data.local.entity.MuhasabaEntity
import com.example.data.local.entity.PrayerRecordEntity
import com.example.data.local.entity.TasbihCounterEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface UnsiDao {
    // --- Favorites ---
    @Query("SELECT * FROM favorites ORDER BY timestamp DESC")
    fun getAllFavorites(): Flow<List<FavoriteEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM favorites WHERE id = :id)")
    fun isFavorite(id: String): Flow<Boolean>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavorite(favorite: FavoriteEntity)

    @Query("DELETE FROM favorites WHERE id = :id")
    suspend fun deleteFavoriteById(id: String)

    // --- Muhasaba (خلوة أُنسي) ---
    @Query("SELECT * FROM muhasaba_records ORDER BY date DESC")
    fun getAllMuhasaba(): Flow<List<MuhasabaEntity>>

    @Query("SELECT * FROM muhasaba_records WHERE date = :date LIMIT 1")
    fun getMuhasabaByDate(date: String): Flow<MuhasabaEntity?>

    @Query("SELECT * FROM muhasaba_records WHERE date = :date LIMIT 1")
    suspend fun getMuhasabaDirect(date: String): MuhasabaEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertMuhasaba(muhasaba: MuhasabaEntity)

    @Query("DELETE FROM muhasaba_records WHERE date = :date")
    suspend fun deleteMuhasaba(date: String)

    // --- Prayer Records ---
    @Query("SELECT * FROM prayer_records WHERE date = :date LIMIT 1")
    fun getPrayerRecord(date: String): Flow<PrayerRecordEntity?>

    @Query("SELECT * FROM prayer_records WHERE date = :date LIMIT 1")
    suspend fun getPrayerRecordDirect(date: String): PrayerRecordEntity?

    @Query("SELECT * FROM prayer_records ORDER BY date DESC LIMIT 30")
    fun getRecentPrayerRecords(): Flow<List<PrayerRecordEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPrayerRecord(record: PrayerRecordEntity)

    // --- Tasbih Counters ---
    @Query("SELECT * FROM tasbih_counters")
    fun getAllTasbihCounters(): Flow<List<TasbihCounterEntity>>

    @Query("SELECT * FROM tasbih_counters WHERE id = :id LIMIT 1")
    fun getTasbihCounter(id: String): Flow<TasbihCounterEntity?>

    @Query("SELECT * FROM tasbih_counters WHERE id = :id LIMIT 1")
    suspend fun getTasbihCounterDirect(id: String): TasbihCounterEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTasbihCounter(counter: TasbihCounterEntity)

    // --- Dhikr Progress ---
    @Query("SELECT * FROM dhikr_progress")
    fun getAllDhikrProgress(): Flow<List<DhikrProgressEntity>>

    @Query("SELECT * FROM dhikr_progress WHERE dhikrId = :id LIMIT 1")
    fun getDhikrProgress(id: String): Flow<DhikrProgressEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertDhikrProgress(progress: DhikrProgressEntity)

    @Query("UPDATE dhikr_progress SET currentCount = 0, isCompleted = 0 WHERE lastCompletedDate != :today")
    suspend fun resetExpiredDhikrDaily(today: String)

    // --- Reset all user data (Privacy & Data Clear) ---
    @Query("DELETE FROM favorites")
    suspend fun clearFavorites()

    @Query("DELETE FROM muhasaba_records")
    suspend fun clearMuhasaba()

    @Query("DELETE FROM prayer_records")
    suspend fun clearPrayerRecords()

    @Query("DELETE FROM dhikr_progress")
    suspend fun clearDhikrProgress()
}
