package com.example.data.local

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.ui.theme.AppThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "unsi_user_prefs")

data class UserSettings(
    val themeMode: AppThemeMode = AppThemeMode.EMERALD_GOLD,
    val fontSizeScale: Float = 1.0f,
    val hapticFeedbackEnabled: Boolean = true,
    val soundEnabled: Boolean = true,
    val ambientDecorationsEnabled: Boolean = true,
    val companionReminderEnabled: Boolean = true,
    val firstLaunchCompleted: Boolean = false,
    val selectedCity: String = "مكة المكرمة",
    val latitude: Double = 21.4225,
    val longitude: Double = 39.8262,
    val prayerCalculationMethod: String = "أم القرى (مكة المكرمة)",
    val dailyTasbihTarget: Int = 100,
    val dailyQuranPagesTarget: Int = 4,
    val lastReadSurahNumber: Int = 1,
    val lastReadAyahNumber: Int = 1,
    val lastReadSurahName: String = "الفاتحة",
    val lastReadPage: Int = 1
)

class UserPreferencesRepository(private val context: Context) {

    private object PreferencesKeys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val FONT_SIZE_SCALE = floatPreferencesKey("font_size_scale")
        val HAPTIC_ENABLED = booleanPreferencesKey("haptic_enabled")
        val SOUND_ENABLED = booleanPreferencesKey("sound_enabled")
        val AMBIENT_ENABLED = booleanPreferencesKey("ambient_enabled")
        val COMPANION_REMINDERS = booleanPreferencesKey("companion_reminders")
        val FIRST_LAUNCH_COMPLETED = booleanPreferencesKey("first_launch_completed")
        val SELECTED_CITY = stringPreferencesKey("selected_city")
        val LATITUDE = floatPreferencesKey("latitude")
        val LONGITUDE = floatPreferencesKey("longitude")
        val PRAYER_METHOD = stringPreferencesKey("prayer_method")
        val DAILY_TASBIH_TARGET = intPreferencesKey("daily_tasbih_target")
        val DAILY_QURAN_PAGES = intPreferencesKey("daily_quran_pages")
        val LAST_SURAH_NUM = intPreferencesKey("last_surah_num")
        val LAST_AYAH_NUM = intPreferencesKey("last_ayah_num")
        val LAST_SURAH_NAME = stringPreferencesKey("last_surah_name")
        val LAST_READ_PAGE = intPreferencesKey("last_read_page")
    }

    val userSettingsFlow: Flow<UserSettings> = context.dataStore.data.map { prefs ->
        val themeString = prefs[PreferencesKeys.THEME_MODE] ?: AppThemeMode.EMERALD_GOLD.name
        val themeMode = try {
            AppThemeMode.valueOf(themeString)
        } catch (e: Exception) {
            AppThemeMode.EMERALD_GOLD
        }

        UserSettings(
            themeMode = themeMode,
            fontSizeScale = prefs[PreferencesKeys.FONT_SIZE_SCALE] ?: 1.0f,
            hapticFeedbackEnabled = prefs[PreferencesKeys.HAPTIC_ENABLED] ?: true,
            soundEnabled = prefs[PreferencesKeys.SOUND_ENABLED] ?: true,
            ambientDecorationsEnabled = prefs[PreferencesKeys.AMBIENT_ENABLED] ?: true,
            companionReminderEnabled = prefs[PreferencesKeys.COMPANION_REMINDERS] ?: true,
            firstLaunchCompleted = prefs[PreferencesKeys.FIRST_LAUNCH_COMPLETED] ?: false,
            selectedCity = prefs[PreferencesKeys.SELECTED_CITY] ?: "مكة المكرمة",
            latitude = (prefs[PreferencesKeys.LATITUDE] ?: 21.4225f).toDouble(),
            longitude = (prefs[PreferencesKeys.LONGITUDE] ?: 39.8262f).toDouble(),
            prayerCalculationMethod = prefs[PreferencesKeys.PRAYER_METHOD] ?: "أم القرى (مكة المكرمة)",
            dailyTasbihTarget = prefs[PreferencesKeys.DAILY_TASBIH_TARGET] ?: 100,
            dailyQuranPagesTarget = prefs[PreferencesKeys.DAILY_QURAN_PAGES] ?: 4,
            lastReadSurahNumber = prefs[PreferencesKeys.LAST_SURAH_NUM] ?: 1,
            lastReadAyahNumber = prefs[PreferencesKeys.LAST_AYAH_NUM] ?: 1,
            lastReadSurahName = prefs[PreferencesKeys.LAST_SURAH_NAME] ?: "الفاتحة",
            lastReadPage = prefs[PreferencesKeys.LAST_READ_PAGE] ?: 1
        )
    }

    suspend fun setThemeMode(mode: AppThemeMode) {
        context.dataStore.edit { it[PreferencesKeys.THEME_MODE] = mode.name }
    }

    suspend fun setFontSizeScale(scale: Float) {
        context.dataStore.edit { it[PreferencesKeys.FONT_SIZE_SCALE] = scale }
    }

    suspend fun setHapticEnabled(enabled: Boolean) {
        context.dataStore.edit { it[PreferencesKeys.HAPTIC_ENABLED] = enabled }
    }

    suspend fun setSoundEnabled(enabled: Boolean) {
        context.dataStore.edit { it[PreferencesKeys.SOUND_ENABLED] = enabled }
    }

    suspend fun setAmbientEnabled(enabled: Boolean) {
        context.dataStore.edit { it[PreferencesKeys.AMBIENT_ENABLED] = enabled }
    }

    suspend fun setCompanionReminders(enabled: Boolean) {
        context.dataStore.edit { it[PreferencesKeys.COMPANION_REMINDERS] = enabled }
    }

    suspend fun setFirstLaunchCompleted(completed: Boolean) {
        context.dataStore.edit { it[PreferencesKeys.FIRST_LAUNCH_COMPLETED] = completed }
    }

    suspend fun setCity(city: String, lat: Double, lng: Double) {
        context.dataStore.edit {
            it[PreferencesKeys.SELECTED_CITY] = city
            it[PreferencesKeys.LATITUDE] = lat.toFloat()
            it[PreferencesKeys.LONGITUDE] = lng.toFloat()
        }
    }

    suspend fun setDailyTargets(tasbih: Int, quranPages: Int) {
        context.dataStore.edit {
            it[PreferencesKeys.DAILY_TASBIH_TARGET] = tasbih
            it[PreferencesKeys.DAILY_QURAN_PAGES] = quranPages
        }
    }

    suspend fun saveLastReadingPosition(surahNum: Int, surahName: String, ayahNum: Int, page: Int) {
        context.dataStore.edit {
            it[PreferencesKeys.LAST_SURAH_NUM] = surahNum
            it[PreferencesKeys.LAST_SURAH_NAME] = surahName
            it[PreferencesKeys.LAST_AYAH_NUM] = ayahNum
            it[PreferencesKeys.LAST_READ_PAGE] = page
        }
    }

    suspend fun clearAllPreferences() {
        context.dataStore.edit { it.clear() }
    }
}
