package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.local.dao.UnsiDao
import com.example.data.local.entity.DhikrProgressEntity
import com.example.data.local.entity.FavoriteEntity
import com.example.data.local.entity.MuhasabaEntity
import com.example.data.local.entity.PrayerRecordEntity
import com.example.data.local.entity.TasbihCounterEntity

@Database(
    entities = [
        FavoriteEntity::class,
        MuhasabaEntity::class,
        PrayerRecordEntity::class,
        TasbihCounterEntity::class,
        DhikrProgressEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class UnsiDatabase : RoomDatabase() {
    abstract fun unsiDao(): UnsiDao

    companion object {
        @Volatile
        private var INSTANCE: UnsiDatabase? = null

        fun getDatabase(context: Context): UnsiDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    UnsiDatabase::class.java,
                    "unsi_islamic_db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
