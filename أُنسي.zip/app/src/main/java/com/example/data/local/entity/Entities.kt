package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "favorites")
data class FavoriteEntity(
    @PrimaryKey
    val id: String,
    val type: String, // "DHIKR" or "AYAH"
    val title: String,
    val contentArabic: String,
    val reference: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "muhasaba_records")
data class MuhasabaEntity(
    @PrimaryKey
    val date: String, // YYYY-MM-DD
    val prayersCompletedCount: Int = 0,
    val quranRead: Boolean = false,
    val adhkarDone: Boolean = false,
    val istighfarDone: Boolean = false,
    val charityDone: Boolean = false,
    val hurtSomeone: Boolean = false,
    val restitutionNeeded: Boolean = false,
    val tomorrowGoal: String = "",
    val habitToImprove: String = "",
    val personalNotes: String = "",
    val peaceRating: Int = 5, // 1 to 5
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "prayer_records")
data class PrayerRecordEntity(
    @PrimaryKey
    val date: String, // YYYY-MM-DD
    val fajrDone: Boolean = false,
    val dhuhrDone: Boolean = false,
    val asrDone: Boolean = false,
    val maghribDone: Boolean = false,
    val ishaDone: Boolean = false,
    val lastUpdated: Long = System.currentTimeMillis()
)

@Entity(tableName = "tasbih_counters")
data class TasbihCounterEntity(
    @PrimaryKey
    val id: String,
    val titleArabic: String,
    val count: Int = 0,
    val target: Int = 33,
    val totalLifetimeCount: Int = 0,
    val lastUpdated: Long = System.currentTimeMillis()
)

@Entity(tableName = "dhikr_progress")
data class DhikrProgressEntity(
    @PrimaryKey
    val dhikrId: String,
    val currentCount: Int = 0,
    val targetCount: Int = 1,
    val isCompleted: Boolean = false,
    val lastCompletedDate: String = "",
    val lastUpdated: Long = System.currentTimeMillis()
)
