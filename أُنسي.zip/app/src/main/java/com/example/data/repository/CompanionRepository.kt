package com.example.data.repository

import com.example.data.model.CompanionChatMessage
import com.example.data.model.CompanionRecommendation
import java.util.Calendar

object CompanionRepository {

    fun getCurrentContextRecommendation(): CompanionRecommendation {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when (hour) {
            in 4..8 -> CompanionRecommendation(
                id = "rec_sabah",
                titleArabic = "بركة الصباح وأُنس البدايات",
                messageArabic = "السلام عليكم ورحمة الله. أشرق يوم جديد، فاجعل أول خطوة فيه حصناً منيعاً بذكر الله، فإن من حفظ أذكار الصباح حفظه الله حتى يمسي.",
                sourceOrFadilah = "قال ﷺ: «من قالها حين يصبح موقناً بها فمات دخل الجنة»",
                actionLabel = "ابدأ أذكار الصباح",
                actionRoute = "adhkar_category/sabah"
            )
            in 9..11 -> CompanionRecommendation(
                id = "rec_duha",
                titleArabic = "صلاة الأوابين والاستغفار",
                messageArabic = "في خضم انشغالاتك وسعيك، ركعتان من صلاة الضحى تعدلان صدقة عن كل مفصل في جسدك. استقطع دقائق تسكن بها روحك.",
                sourceOrFadilah = "«يصبح على كل سلامى من أحدكم صدقة... ويجزئ من ذلك ركعتان يركعهما من الضحى»",
                actionLabel = "افتح السبحة الإلكترونية",
                actionRoute = "tasbih"
            )
            in 12..15 -> CompanionRecommendation(
                id = "rec_dhuhr",
                titleArabic = "أجر ما بعد الفريضة",
                messageArabic = "هل أتممت أذكار ما بعد الصلاة؟ التسبيح والتحميد والتكبير بعد الفريضة من أعظم القربات التي تغفر بها الخطايا وإن كانت مثل زبد البحر.",
                sourceOrFadilah = "«تسبحون وتحمدون وتكبرون دبر كل صلاة ثلاثاً وثلاثين»",
                actionLabel = "أذكار بعد الصلاة",
                actionRoute = "adhkar_category/post_prayer"
            )
            in 16..18 -> CompanionRecommendation(
                id = "rec_masaa",
                titleArabic = "سكينة المساء وحصن الليلة",
                messageArabic = "مالت الشمس إلى المغيب، وجاء وقت حماية روحك وأهلك بأذكار المساء. حصّن نفسك بكلمات الله التامات من كل شر.",
                sourceOrFadilah = "«من قالها لم يضره شيء حتى يمسي / يصبح»",
                actionLabel = "أذكار المساء",
                actionRoute = "adhkar_category/masaa"
            )
            in 19..21 -> CompanionRecommendation(
                id = "rec_quran",
                titleArabic = "أُنس القرآن الكريم",
                messageArabic = "اجعل لليلتك نصيباً من نور التنزيل. قراءة صفحة واحدة بتدبر خير من الدنيا وما فيها، والقرآن يشفع لأصحابه يوم القيامة.",
                sourceOrFadilah = "«اقرؤوا القرآن فإنه يأتي يوم القيامة شفيعاً لأصحابه»",
                actionLabel = "متابعة قراءة القرآن",
                actionRoute = "quran"
            )
            else -> CompanionRecommendation(
                id = "rec_muhasaba",
                titleArabic = "خلوة أُنسي ومحاسبة النفس",
                messageArabic = "شارف اليوم على الانتهاء. اجلس مع نفسك لحظات صدق، حاسبها بلطف، جدد توبتك، واعزم على الغد بقلب سليم قبل أن تضع جنبك.",
                sourceOrFadilah = "«حاسبوا أنفسكم قبل أن تُحاسبوا، وزنوها قبل أن تُوزنوا»",
                actionLabel = "ابدأ جلسة المحاسبة الليلة",
                actionRoute = "muhasaba"
            )
        }
    }

    fun generateReply(userPrompt: String): CompanionChatMessage {
        val q = AdhkarRepository.normalizeArabic(userPrompt.trim())

        return when {
            q.contains("ورد") || q.contains("خطة") || q.contains("برنامج") -> {
                CompanionChatMessage(
                    id = System.currentTimeMillis().toString(),
                    isFromCompanion = true,
                    text = "أقترح عليك ورداً يومياً مباركاً وخفيفاً يسهل الاستمرار عليه:\n• أذكار الصباح والمساء (10 دقائق)\n• 100 تسبيحة واستغفار بالسبحة\n• قراءة 4 صفحات من القرآن بتأنٍ\n• خلوة محاسبة النفس لـ 3 دقائق قبل النوم.\n«أحب الأعمال إلى الله أدومها وإن قل».",
                    actionButtonText = "عرض خطة الورد",
                    actionRoute = "wird_plan"
                )
            }
            q.contains("ضيق") || q.contains("هم") || q.contains("كرب") || q.contains("حزن") || q.contains("تعب") -> {
                CompanionChatMessage(
                    id = System.currentTimeMillis().toString(),
                    isFromCompanion = true,
                    text = "هوّن عليك أخي الفاضل، ما من شدة إلا ويزيلها الله برحمته. لا تغفل عن دعوة ذي النون في بطن الظلمات:\n«لا إِلَهَ إِلا أَنْتَ سُبْحَانَكَ إِنِّي كُنْتُ مِنَ الظَّالِمِينَ»\nفإنه ما دعا بها مكروب إلا فرّج الله عنه. ألا بذكر الله تطمئن القلوب.",
                    actionButtonText = "أدعية الكرب والهم",
                    actionRoute = "adhkar_category/distress"
                )
            }
            q.contains("استغفار") || q.contains("توبة") || q.contains("ذنب") -> {
                CompanionChatMessage(
                    id = System.currentTimeMillis().toString(),
                    isFromCompanion = true,
                    text = "باب التوبة مفتوح على مصراعيه دائماً، والله يفرح بتوبة عبده. الزم «سيد الاستغفار» وأكثر من: «أستغفر الله وأتوب إليه»، فإن الاستغفار يفتح الأقفال ويشرح البال ويزيد الرزق.",
                    actionButtonText = "أدعية الاستغفار والتوبة",
                    actionRoute = "adhkar_category/istighfar"
                )
            }
            q.contains("صلاة") || q.contains("صليت") || q.contains("فجر") || q.contains("وقت") -> {
                CompanionChatMessage(
                    id = System.currentTimeMillis().toString(),
                    isFromCompanion = true,
                    text = "الصلاة هي عمود الدين وحبل الصلة بين العبد وخالقه. يمكنك متابعة مواقيت الصلاة بدقة لمعرفة الوقت المتبقي، وتسجيل أداء كل فريضة يومياً لتثبيت التزامك.",
                    actionButtonText = "عرض مواقيت الصلاة",
                    actionRoute = "prayer_times"
                )
            }
            q.contains("محاسبة") || q.contains("خلوة") || q.contains("نفس") -> {
                CompanionChatMessage(
                    id = System.currentTimeMillis().toString(),
                    isFromCompanion = true,
                    text = "«خلوة أُنسي» مخصصة لتجلس مع نفسك بصدق ومحبة، دون جلد للذات ودون تكلف. تجيب فيها عن أسئلة بسيطة تحفظ محلياً على جهازك، وتضع هدفاً طيباً لليوم التالي.",
                    actionButtonText = "بدء خلوة المحاسبة",
                    actionRoute = "muhasaba"
                )
            }
            q.contains("سبحة") || q.contains("تسبيح") || q.contains("عداد") -> {
                CompanionChatMessage(
                    id = System.currentTimeMillis().toString(),
                    isFromCompanion = true,
                    text = "السبحة الإلكترونية في «أُنسي» تتيح لك التسبيح باللمس مع اهتزاز تفاعلي لطيف وحفظ تلقائي لإجمالي تسبيحاتك وأهدافك اليومية.",
                    actionButtonText = "فتح السبحة الإلكترونية",
                    actionRoute = "tasbih"
                )
            }
            q.contains("قران") || q.contains("سورة") || q.contains("اية") -> {
                CompanionChatMessage(
                    id = System.currentTimeMillis().toString(),
                    isFromCompanion = true,
                    text = "القرآن هو الأُنس والشفاء والهدى. يمكنك تصفح فهرس السور الـ114، ومتابعة آخر موضع قراءة توقفت عنده، والاستماع للتلاوات العذبة.",
                    actionButtonText = "تصفح المصحف الشريف",
                    actionRoute = "quran"
                )
            }
            else -> {
                CompanionChatMessage(
                    id = System.currentTimeMillis().toString(),
                    isFromCompanion = true,
                    text = "أنا رفيقك الإيماني «أُنسي»، هنا لأعينك على ذكر الله ومراجعة نيتك وتنظيم وردك اليومي. يمكنك سؤالي عن اقتراح ورد، أو طلب ذكر مناسب للوقت، أو البدء في جلسة محاسبة النفس.",
                    actionButtonText = "استكشف مكتبة الأذكار",
                    actionRoute = "adhkar"
                )
            }
        }
    }
}
