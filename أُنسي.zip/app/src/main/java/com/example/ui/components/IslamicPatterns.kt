package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import com.example.ui.theme.GoldRadiant

@Composable
fun IslamicBackgroundPattern(
    modifier: Modifier = Modifier,
    enableAnimation: Boolean = true,
    content: @Composable () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "ambient_glow")
    val alphaAnim by if (enableAnimation) {
        infiniteTransition.animateFloat(
            initialValue = 0.03f,
            targetValue = 0.08f,
            animationSpec = infiniteRepeatable(
                animation = tween(4000, easing = LinearEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "ambient_alpha"
        )
    } else {
        androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(0.04f) }
    }

    val primaryBg = MaterialTheme.colorScheme.background
    val surfaceColor = MaterialTheme.colorScheme.surface

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        surfaceColor,
                        primaryBg,
                        primaryBg
                    )
                )
            )
    ) {
        // Decorative geometric canvas overlay
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            // Subtle Islamic arch curve at top
            val archPath = Path().apply {
                moveTo(0f, 0f)
                lineTo(width, 0f)
                lineTo(width, height * 0.12f)
                cubicTo(
                    width * 0.75f, height * 0.15f,
                    width * 0.25f, height * 0.15f,
                    0f, height * 0.12f
                )
                close()
            }
            drawPath(
                path = archPath,
                color = GoldRadiant.copy(alpha = alphaAnim)
            )

            // Repeating 8-pointed star pattern lattice
            val step = 160f
            var y = 80f
            while (y < height) {
                var x = 80f
                while (x < width) {
                    drawIslamicStar(
                        center = Offset(x, y),
                        outerRadius = 24f,
                        innerRadius = 12f,
                        color = GoldRadiant.copy(alpha = alphaAnim * 0.8f)
                    )
                    x += step
                }
                y += step
            }
        }

        content()
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawIslamicStar(
    center: Offset,
    outerRadius: Float,
    innerRadius: Float,
    color: Color
) {
    val path = Path()
    val numPoints = 8
    val angleStep = Math.PI / numPoints

    for (i in 0 until numPoints * 2) {
        val r = if (i % 2 == 0) outerRadius else innerRadius
        val angle = i * angleStep
        val px = (center.x + r * Math.cos(angle)).toFloat()
        val py = (center.y + r * Math.sin(angle)).toFloat()
        if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
    }
    path.close()

    drawPath(
        path = path,
        color = color,
        style = Stroke(width = 1.2f)
    )
}
