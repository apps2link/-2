package com.example.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CompassCalibration
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.CityLocation
import com.example.data.repository.PrayerTimesCalculator
import com.example.ui.components.LuxuryCard
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldRadiant
import com.example.ui.viewmodel.MainViewModel

data class PrayerRowItem(
    val id: String,
    val nameArabic: String,
    val timeFormatted: String,
    val isNext: Boolean,
    val isDone: Boolean
)

@Composable
fun PrayerTimesScreen(
    viewModel: MainViewModel,
    onNavigateToQibla: () -> Unit,
    onBack: () -> Unit
) {
    val userSettings by viewModel.userSettings.collectAsState()
    val prayerTimes by viewModel.dailyPrayerTimes.collectAsState()
    val prayerRecord by viewModel.prayerRecord.collectAsState()

    var showCityDialog by remember { mutableStateOf(false) }

    val rows = listOf(
        PrayerRowItem("fajr", "صلاة الفجر", prayerTimes.fajr, prayerTimes.nextPrayerName == "الفجر", prayerRecord?.fajrDone == true),
        PrayerRowItem("sunrise", "الشروق", prayerTimes.sunrise, false, false),
        PrayerRowItem("dhuhr", "صلاة الظهر", prayerTimes.dhuhr, prayerTimes.nextPrayerName == "الظهر", prayerRecord?.dhuhrDone == true),
        PrayerRowItem("asr", "صلاة العصر", prayerTimes.asr, prayerTimes.nextPrayerName == "العصر", prayerRecord?.asrDone == true),
        PrayerRowItem("maghrib", "صلاة المغرب", prayerTimes.maghrib, prayerTimes.nextPrayerName == "المغرب", prayerRecord?.maghribDone == true),
        PrayerRowItem("isha", "صلاة العشاء", prayerTimes.isha, prayerTimes.nextPrayerName == "العشاء", prayerRecord?.ishaDone == true)
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        // Top Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "رجوع",
                    tint = MaterialTheme.colorScheme.onBackground
                )
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "مواقيت الصلاة",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onBackground,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = prayerTimes.dateHijri,
                    style = MaterialTheme.typography.labelSmall,
                    color = GoldRadiant
                )
            }

            // Qibla button
            IconButton(onClick = onNavigateToQibla) {
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.primaryContainer,
                    border = BorderStroke(1.dp, GoldRadiant.copy(alpha = 0.5f)),
                    modifier = Modifier.size(38.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Explore,
                            contentDescription = "القبلة",
                            tint = GoldRadiant,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Current City Banner with change button
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .clickable { showCityDialog = true },
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, GoldRadiant.copy(alpha = 0.35f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = null,
                        tint = GoldRadiant,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "المدينة: ${userSettings.selectedCity}",
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.Bold
                    )
                }

                Text(
                    text = "تغيير المدينة ▾",
                    style = MaterialTheme.typography.labelSmall,
                    color = GoldRadiant
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Countdown Card to Next Prayer
        LuxuryCard(borderAlpha = 0.6f) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "الصلاة القادمة: صلاة ${prayerTimes.nextPrayerName}",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "متبقي ${prayerTimes.minutesRemaining} دقيقة",
                    style = MaterialTheme.typography.displayMedium,
                    color = GoldAccent,
                    fontWeight = FontWeight.ExtraBold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "حساب فلكي دقيق وفق تقويم أم القرى",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "جدول اليوم وسجل الصلوات (اضغط لتسجيل الأداء):",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 90.dp)
        ) {
            items(rows) { row ->
                val isClickable = row.id != "sunrise"

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .clickable(enabled = isClickable) {
                            viewModel.togglePrayer(row.id)
                        },
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (row.isNext) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
                    ),
                    border = BorderStroke(
                        1.dp,
                        if (row.isNext) GoldRadiant else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (isClickable) {
                                Icon(
                                    imageVector = if (row.isDone) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                    contentDescription = "تسجيل الأداء",
                                    tint = if (row.isDone) GoldRadiant else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                            }
                            Column {
                                Text(
                                    text = row.nameArabic,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = if (row.isNext) GoldRadiant else MaterialTheme.colorScheme.onSurface,
                                    fontWeight = if (row.isNext) FontWeight.Bold else FontWeight.SemiBold
                                )
                                if (row.isDone) {
                                    Text(
                                        text = "تم أداء الصلاة بحمد الله ✓",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = GoldRadiant
                                    )
                                }
                            }
                        }

                        Text(
                            text = row.timeFormatted,
                            style = MaterialTheme.typography.titleMedium,
                            color = if (row.isNext) GoldAccent else MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }

    // City selector dialog
    if (showCityDialog) {
        AlertDialog(
            onDismissRequest = { showCityDialog = false },
            title = { Text("اختر المدينة لحساب المواقيت") },
            text = {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp)
                ) {
                    items(PrayerTimesCalculator.popularCities) { city ->
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .clickable {
                                    viewModel.setCity(city.nameArabic, city.latitude, city.longitude)
                                    showCityDialog = false
                                },
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = city.nameArabic,
                                    style = MaterialTheme.typography.titleSmall,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = city.countryArabic,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showCityDialog = false }) {
                    Text("إغلاق")
                }
            }
        )
    }
}

// 2. Qibla Direction Screen
@Composable
fun QiblaScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit
) {
    val userSettings by viewModel.userSettings.collectAsState()
    val qiblaBearing = PrayerTimesCalculator.calculateQiblaBearing(
        userSettings.latitude,
        userSettings.longitude
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "رجوع",
                    tint = MaterialTheme.colorScheme.onBackground
                )
            }
            Text(
                text = "بوصلة اتجاه القبلة",
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onBackground,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.size(40.dp))
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "«فَوَلِّ وَجْهَكَ شَطْرَ الْمَسْجِدِ الْحَرَامِ»",
            style = MaterialTheme.typography.titleMedium,
            color = GoldRadiant,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "الموقع الحالي: ${userSettings.selectedCity}",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(30.dp))

        // Compass Visual Needle
        Surface(
            shape = CircleShape,
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(3.dp, GoldRadiant),
            modifier = Modifier.size(240.dp)
        ) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                ) {
                    val center = this.center
                    val radius = size.minDimension / 2f

                    // Dial circles
                    drawCircle(
                        color = GoldRadiant.copy(alpha = 0.2f),
                        radius = radius,
                        style = Stroke(width = 2.dp.toPx())
                    )

                    // Cardinal marks
                    val markLength = 12.dp.toPx()
                    for (i in 0 until 360 step 30) {
                        val angle = Math.toRadians(i.toDouble())
                        val start = Offset(
                            (center.x + (radius - markLength) * Math.sin(angle)).toFloat(),
                            (center.y - (radius - markLength) * Math.cos(angle)).toFloat()
                        )
                        val end = Offset(
                            (center.x + radius * Math.sin(angle)).toFloat(),
                            (center.y - radius * Math.cos(angle)).toFloat()
                        )
                        drawLine(
                            color = if (i % 90 == 0) GoldAccent else GoldRadiant.copy(alpha = 0.4f),
                            start = start,
                            end = end,
                            strokeWidth = if (i % 90 == 0) 3.dp.toPx() else 1.5.dp.toPx()
                        )
                    }
                }

                // Needle pointing to Qibla bearing
                Box(
                    modifier = Modifier
                        .size(180.dp)
                        .rotate(qiblaBearing.toFloat()),
                    contentAlignment = Alignment.TopCenter
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Surface(
                            shape = CircleShape,
                            color = GoldAccent,
                            modifier = Modifier.size(22.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text("🕋", fontSize = 12.sp)
                            }
                        }
                        Box(
                            modifier = Modifier
                                .width(4.dp)
                                .height(70.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(GoldRadiant)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(30.dp))

        LuxuryCard(borderAlpha = 0.4f) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "زاوية القبلة بالنسبة للشمال الحقيقي",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = String.format("%.1f°", qiblaBearing),
                    style = MaterialTheme.typography.displayMedium,
                    color = GoldAccent,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "وجّه هاتفك بحيث تتطابق الإبرة مع رمز الكعبة المشرفة",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}
