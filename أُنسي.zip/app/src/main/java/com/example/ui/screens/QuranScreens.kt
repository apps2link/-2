package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.PlayerState
import com.example.audio.ReciterInfo
import com.example.data.repository.QuranRepository
import com.example.ui.components.HapticFeedbackHelper
import com.example.ui.components.LuxuryCard
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldRadiant
import com.example.ui.viewmodel.MainViewModel

// 1. Quran Catalog Screen (فهرس السور الـ114)
@Composable
fun QuranCatalogScreen(
    viewModel: MainViewModel,
    onSurahClick: (Int) -> Unit,
    onAudioClick: (Int) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val userSettings by viewModel.userSettings.collectAsState()
    val surahs = QuranRepository.searchSurahs(searchQuery)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        // Title & Audio Player quick button
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "المصحف الشريف",
                    style = MaterialTheme.typography.headlineLarge,
                    color = MaterialTheme.colorScheme.onBackground,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "فهرس السور الـ 114 بالترتيب العثماني",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            IconButton(
                onClick = { onAudioClick(1) }
            ) {
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.primaryContainer,
                    border = BorderStroke(1.dp, GoldRadiant.copy(alpha = 0.5f)),
                    modifier = Modifier.size(40.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Headphones,
                            contentDescription = "مشغل التلاوات",
                            tint = GoldRadiant,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Last Read Banner
        LuxuryCard(
            onClick = { onSurahClick(userSettings.lastReadSurahNumber) },
            borderAlpha = 0.45f
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = null,
                        tint = GoldRadiant,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "متابعة آخر قراءة",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "سورة ${userSettings.lastReadSurahName} (صفحة ${userSettings.lastReadPage})",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onBackground,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Text(
                    text = "متابعة ←",
                    style = MaterialTheme.typography.labelMedium,
                    color = GoldRadiant,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("ابحث باسم السورة أو رقمها...") },
            leadingIcon = {
                Icon(Icons.Default.Search, contentDescription = null, tint = GoldRadiant)
            },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { searchQuery = "" }) {
                        Icon(Icons.Default.Clear, contentDescription = "مسح")
                    }
                }
            },
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = GoldRadiant,
                unfocusedBorderColor = MaterialTheme.colorScheme.outline
            ),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(14.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 100.dp)
        ) {
            items(surahs) { surah ->
                LuxuryCard(
                    onClick = { onSurahClick(surah.number) },
                    borderAlpha = 0.3f
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primaryContainer,
                            border = BorderStroke(1.dp, GoldRadiant.copy(alpha = 0.3f)),
                            modifier = Modifier.size(42.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = "${surah.number}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = GoldRadiant,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "سورة ${surah.nameArabic}",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onBackground,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                                ) {
                                    Text(
                                        text = surah.revelationType,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = GoldRadiant,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "آياتها ${surah.versesCount} • الجزء ${surah.juzStart} • صفحة ${surah.pageStart}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        IconButton(
                            onClick = { onAudioClick(surah.number) }
                        ) {
                            Icon(
                                imageVector = Icons.Default.Headphones,
                                contentDescription = "استماع",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

// 2. Quran Reader Screen (شاشة قراءة القرآن الكريم)
@Composable
fun QuranReaderScreen(
    surahNumber: Int,
    viewModel: MainViewModel,
    onBack: () -> Unit,
    onSurahChange: (Int) -> Unit
) {
    val context = LocalContext.current
    val userSettings by viewModel.userSettings.collectAsState()
    val favorites by viewModel.favorites.collectAsState()

    var fontSizeSp by remember { mutableFloatStateOf(24f) }
    var showFontControls by remember { mutableStateOf(false) }

    val surah = QuranRepository.getSurahByNumber(surahNumber) ?: QuranRepository.surahs[0]
    val verses = QuranRepository.getVersesForSurah(surah.number)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        // Top Navigation Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "رجوع",
                    tint = MaterialTheme.colorScheme.onBackground
                )
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "سورة ${surah.nameArabic}",
                    style = MaterialTheme.typography.headlineMedium,
                    color = GoldRadiant,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${surah.revelationType} • ${surah.versesCount} آيات • الجزء ${surah.juzStart}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            IconButton(
                onClick = {
                    viewModel.saveLastReadingPosition(
                        surah.number,
                        surah.nameArabic,
                        1,
                        surah.pageStart
                    )
                    HapticFeedbackHelper.performClick(context, userSettings.hapticFeedbackEnabled)
                }
            ) {
                Icon(
                    imageVector = Icons.Default.Bookmark,
                    contentDescription = "حفظ موضع القراءة",
                    tint = GoldRadiant
                )
            }
        }

        // Font Size Adjuster Drawer / Toggle
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("حجم الخط: ", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Slider(
                value = fontSizeSp,
                onValueChange = { fontSizeSp = it },
                valueRange = 18f..36f,
                modifier = Modifier.width(180.dp),
                colors = SliderDefaults.colors(
                    thumbColor = GoldRadiant,
                    activeTrackColor = GoldRadiant
                )
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Verses View
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 90.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Basmalah Header (except At-Tawbah)
            if (surah.number != 9) {
                item {
                    LuxuryCard(borderAlpha = 0.4f) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 18.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ",
                                style = MaterialTheme.typography.headlineMedium.copy(
                                    fontSize = (fontSizeSp + 2).sp,
                                    lineHeight = (fontSizeSp * 1.8f).sp
                                ),
                                color = GoldAccent,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }

            items(verses) { ayah ->
                val favId = "ayah_${ayah.surahNumber}_${ayah.ayahNumber}"
                val isFav = favorites.any { it.id == favId }

                LuxuryCard(borderAlpha = 0.35f) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp)
                    ) {
                        Text(
                            text = "${ayah.textArabic} ﴿${ayah.ayahNumber}﴾",
                            style = MaterialTheme.typography.bodyLarge.copy(
                                fontSize = fontSizeSp.sp,
                                lineHeight = (fontSizeSp * 1.8f).sp
                            ),
                            color = MaterialTheme.colorScheme.onSurface,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth(),
                            fontWeight = FontWeight.Medium
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            IconButton(
                                onClick = {
                                    viewModel.toggleFavorite(
                                        id = favId,
                                        type = "AYAH",
                                        title = "سورة ${surah.nameArabic} - آية ${ayah.ayahNumber}",
                                        content = ayah.textArabic,
                                        ref = "سورة ${surah.nameArabic} [${ayah.ayahNumber}]"
                                    )
                                    HapticFeedbackHelper.performClick(context, userSettings.hapticFeedbackEnabled)
                                }
                            ) {
                                Icon(
                                    imageVector = if (isFav) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                                    contentDescription = "حفظ الآية",
                                    tint = if (isFav) GoldRadiant else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            IconButton(
                                onClick = {
                                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(
                                            Intent.EXTRA_TEXT,
                                            "﴿ ${ayah.textArabic} ﴾\n[سورة ${surah.nameArabic}: ${ayah.ayahNumber}]\n\nعبر تطبيق «أُنسي» - رفيقك إلى الله."
                                        )
                                    }
                                    context.startActivity(Intent.createChooser(shareIntent, "مشاركة الآية"))
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Share,
                                    contentDescription = "مشاركة الآية",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Bottom Navigation between Surahs
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    if (surah.number > 1) {
                        Button(
                            onClick = { onSurahChange(surah.number - 1) },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primaryContainer,
                                contentColor = MaterialTheme.colorScheme.primary
                            )
                        ) {
                            Text("← السورة السابقة")
                        }
                    } else {
                        Spacer(modifier = Modifier.width(1.dp))
                    }

                    if (surah.number < 114) {
                        Button(
                            onClick = { onSurahChange(surah.number + 1) },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primaryContainer,
                                contentColor = MaterialTheme.colorScheme.primary
                            )
                        ) {
                            Text("السورة التالية →")
                        }
                    }
                }
            }
        }
    }
}

// 3. Audio Player Screen (مشغل التلاوات المعتمدة)
@Composable
fun AudioPlayerScreen(
    initialSurahNumber: Int = 1,
    viewModel: MainViewModel,
    onBack: () -> Unit
) {
    val player = viewModel.audioPlayer
    val playerState by player.playerState.collectAsState()
    val currentTrack by player.currentTrack.collectAsState()
    val currentPosMs by player.currentPositionMs.collectAsState()
    val durationMs by player.durationMs.collectAsState()
    val reciters = player.availableReciters
    val selectedReciter by player.selectedReciter.collectAsState()
    val playbackSpeed by player.playbackSpeed.collectAsState()
    val errorMsg by player.errorMessage.collectAsState()

    var selectedSurahNum by remember { mutableStateOf(initialSurahNumber) }
    val surah = QuranRepository.getSurahByNumber(selectedSurahNum) ?: QuranRepository.surahs[0]

    val speeds = listOf(0.75f, 1.0f, 1.25f, 1.5f)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        // Top Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "رجوع",
                    tint = MaterialTheme.colorScheme.onBackground
                )
            }

            Text(
                text = "مشغل التلاوات الصوتية",
                style = MaterialTheme.typography.titleMedium,
                color = GoldRadiant,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.size(40.dp))
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Big Audio Art Banner
        Surface(
            shape = CircleShape,
            color = MaterialTheme.colorScheme.primaryContainer,
            border = BorderStroke(2.dp, GoldRadiant),
            modifier = Modifier.size(140.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = Icons.Default.Headphones,
                    contentDescription = null,
                    tint = GoldAccent,
                    modifier = Modifier.size(64.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Track Title & Reciter
        Text(
            text = "سورة ${surah.nameArabic}",
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onBackground,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = selectedReciter.nameArabic,
            style = MaterialTheme.typography.bodyMedium,
            color = GoldRadiant
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Reciters Selector
        Text(
            text = "اختر القارئ المفضل:",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(6.dp))
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .height(100.dp)
        ) {
            items(reciters) { reciter ->
                val isSelected = reciter.id == selectedReciter.id
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { player.selectReciter(reciter) },
                    shape = RoundedCornerShape(10.dp),
                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, GoldRadiant.copy(alpha = if (isSelected) 0.8f else 0.2f))
                ) {
                    Text(
                        text = reciter.nameArabic,
                        style = MaterialTheme.typography.labelMedium,
                        color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(10.dp),
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Error message if any
        if (errorMsg != null) {
            Text(
                text = errorMsg ?: "",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(10.dp))
        }

        // Seekbar
        val posSeconds = currentPosMs / 1000
        val durSeconds = durationMs / 1000
        val posFormatted = String.format("%02d:%02d", posSeconds / 60, posSeconds % 60)
        val durFormatted = String.format("%02d:%02d", durSeconds / 60, durSeconds % 60)

        Slider(
            value = if (durationMs > 0) currentPosMs.toFloat() else 0f,
            onValueChange = { player.seekTo(it.toInt()) },
            valueRange = 0f..(if (durationMs > 0) durationMs.toFloat() else 1f),
            colors = SliderDefaults.colors(
                thumbColor = GoldRadiant,
                activeTrackColor = GoldRadiant
            ),
            modifier = Modifier.fillMaxWidth()
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(posFormatted, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(durFormatted, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Playback Controls Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { player.skipBackward10Sec() }) {
                Icon(
                    imageVector = Icons.Default.Replay10,
                    contentDescription = "تراجع 10 ثوانٍ",
                    tint = GoldRadiant,
                    modifier = Modifier.size(32.dp)
                )
            }

            Surface(
                modifier = Modifier
                    .size(68.dp)
                    .clip(CircleShape)
                    .clickable {
                        if (playerState == PlayerState.IDLE || currentTrack == null) {
                            player.playSurah(surah.number, surah.nameArabic)
                        } else {
                            player.togglePlayPause()
                        }
                    },
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primary,
                border = BorderStroke(2.dp, GoldRadiant)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    val isPlaying = playerState == PlayerState.PLAYING
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (isPlaying) "إيقاف مؤقت" else "تشغيل",
                        tint = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.size(36.dp)
                    )
                }
            }

            IconButton(onClick = { player.skipForward10Sec() }) {
                Icon(
                    imageVector = Icons.Default.Forward10,
                    contentDescription = "تقدم 10 ثوانٍ",
                    tint = GoldRadiant,
                    modifier = Modifier.size(32.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Speed Selector
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("السرعة: ", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            speeds.forEach { speed ->
                val isSelected = playbackSpeed == speed
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isSelected) GoldRadiant else MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, GoldRadiant.copy(alpha = 0.5f)),
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { player.setSpeed(speed) }
                ) {
                    Text(
                        text = "${speed}x",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isSelected) MaterialTheme.colorScheme.background else MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }
    }
}
