package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.LuxuryCard
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldRadiant
import com.example.ui.viewmodel.MainViewModel

// 1. Companion Screen (رفيق أُنسي)
@Composable
fun CompanionScreen(
    viewModel: MainViewModel,
    onNavigate: (String) -> Unit,
    onBack: () -> Unit
) {
    val messages by viewModel.chatMessages.collectAsState()
    var inputText by remember { mutableStateOf("") }

    val quickChips = listOf(
        "اقترح عليّ ورداً يومياً",
        "أشعر بضيق وهم في صدري",
        "أريد دعاء الاستغفار والتوبة",
        "كيف أحافظ على الصلاة في وقتها؟",
        "ساعدني في خطة محاسبة النفس الليلة"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        // Top Bar with Persona Avatar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "رجوع",
                    tint = MaterialTheme.colorScheme.onBackground
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.primaryContainer,
                    border = BorderStroke(1.5.dp, GoldRadiant),
                    modifier = Modifier.size(38.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = GoldRadiant,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "رفيق أُنسي",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onBackground,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "ناصح أمين • رفيقك إلى الله",
                        style = MaterialTheme.typography.labelSmall,
                        color = GoldRadiant
                    )
                }
            }

            Spacer(modifier = Modifier.size(40.dp))
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Quick Suggestion Chips
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(quickChips) { chip ->
                Surface(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { viewModel.sendCompanionMessage(chip) },
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, GoldRadiant.copy(alpha = 0.35f))
                ) {
                    Text(
                        text = chip,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Chat Messages List
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 12.dp)
        ) {
            items(messages) { msg ->
                val isCompanion = msg.isFromCompanion
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (isCompanion) Arrangement.Start else Arrangement.End
                ) {
                    Surface(
                        shape = RoundedCornerShape(
                            topStart = 18.dp,
                            topEnd = 18.dp,
                            bottomStart = if (isCompanion) 4.dp else 18.dp,
                            bottomEnd = if (isCompanion) 18.dp else 4.dp
                        ),
                        color = if (isCompanion) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.primary,
                        border = BorderStroke(
                            1.dp,
                            if (isCompanion) GoldRadiant.copy(alpha = 0.35f) else Color.Transparent
                        ),
                        modifier = Modifier.fillMaxWidth(0.88f)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = msg.text,
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (isCompanion) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onPrimary,
                                lineHeight = 22.sp
                            )

                            if (msg.actionButtonText != null && msg.actionRoute != null) {
                                Spacer(modifier = Modifier.height(10.dp))
                                Button(
                                    onClick = { onNavigate(msg.actionRoute) },
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = MaterialTheme.colorScheme.primaryContainer,
                                        contentColor = MaterialTheme.colorScheme.primary
                                    )
                                ) {
                                    Text(
                                        text = msg.actionButtonText,
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Input Field & Send Button
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = inputText,
                onValueChange = { inputText = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("اكتب رسالتك لرفيق أُنسي...") },
                shape = RoundedCornerShape(20.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = GoldRadiant,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline
                ),
                singleLine = true
            )

            Spacer(modifier = Modifier.width(8.dp))

            Surface(
                modifier = Modifier
                    .size(50.dp)
                    .clip(CircleShape)
                    .clickable {
                        if (inputText.isNotBlank()) {
                            viewModel.sendCompanionMessage(inputText)
                            inputText = ""
                        }
                    },
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primary,
                border = BorderStroke(1.5.dp, GoldRadiant)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = "إرسال",
                        tint = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        }
    }
}

// 2. Muhasaba Screen (خلوة أُنسي - محاسبة النفس)
@Composable
fun MuhasabaScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit
) {
    val existingRecord by viewModel.muhasabaRecord.collectAsState()
    val allHistory by viewModel.allMuhasabaHistory.collectAsState()

    var showHistory by remember { mutableStateOf(false) }

    var prayersScore by remember { mutableIntStateOf(existingRecord?.prayersCompletedCount ?: 5) }
    var quranRead by remember { mutableStateOf(existingRecord?.quranRead ?: true) }
    var adhkarDone by remember { mutableStateOf(existingRecord?.adhkarDone ?: true) }
    var istighfarDone by remember { mutableStateOf(existingRecord?.istighfarDone ?: true) }
    var charityDone by remember { mutableStateOf(existingRecord?.charityDone ?: false) }
    var hurtSomeone by remember { mutableStateOf(existingRecord?.hurtSomeone ?: false) }
    var tomorrowGoal by remember { mutableStateOf(existingRecord?.tomorrowGoal ?: "") }
    var habitToImprove by remember { mutableStateOf(existingRecord?.habitToImprove ?: "") }
    var notes by remember { mutableStateOf(existingRecord?.personalNotes ?: "") }
    var peaceRating by remember { mutableIntStateOf(existingRecord?.peaceRating ?: 5) }
    var isSavedNotification by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        // Top Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "رجوع",
                    tint = MaterialTheme.colorScheme.onBackground
                )
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "خلوة أُنسي",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onBackground,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "محاسبة النفس كل ليلة بصدق ورحمة",
                    style = MaterialTheme.typography.labelSmall,
                    color = GoldRadiant
                )
            }

            IconButton(onClick = { showHistory = !showHistory }) {
                Icon(
                    imageVector = Icons.Default.History,
                    contentDescription = "السجل السابق",
                    tint = GoldRadiant
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (showHistory) {
            Text(
                text = "سجل خلواتك السابقة:",
                style = MaterialTheme.typography.titleMedium,
                color = GoldRadiant,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 90.dp)
            ) {
                items(allHistory) { item ->
                    LuxuryCard(borderAlpha = 0.35f) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "تاريخ: ${item.date}",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = GoldRadiant,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${"⭐".repeat(item.peaceRating)}",
                                    fontSize = 12.sp
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "صلوات: ${item.prayersCompletedCount}/5 • قرآن: ${if (item.quranRead) "نعم" else "لا"} • أذكار: ${if (item.adhkarDone) "نعم" else "لا"}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            if (item.tomorrowGoal.isNotBlank()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "هدف الغد: ${item.tomorrowGoal}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(bottom = 90.dp)
            ) {
                // Header Inspiration Quote
                item {
                    LuxuryCard(borderAlpha = 0.4f) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "«حَاسِبُوا أَنْفُسَكُمْ قَبْلَ أَنْ تُحَاسَبُوا، وَزِنُوهَا قَبْلَ أَنْ تُوزَنُوا»",
                                style = MaterialTheme.typography.titleSmall,
                                color = GoldAccent,
                                textAlign = TextAlign.Center,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "خلوة خاصة بينك وبين الله، تحفظ محلياً على جهازك ولا يطّلع عليها أحد",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                // Question 1: Prayers
                item {
                    LuxuryCard(borderAlpha = 0.3f) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "1. كم صلاة مفروضة حافظت عليها اليوم؟ ($prayersScore من 5)",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                (0..5).forEach { num ->
                                    val isSelected = prayersScore == num
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
                                        border = BorderStroke(1.dp, GoldRadiant.copy(alpha = 0.4f)),
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(10.dp))
                                            .clickable { prayersScore = num }
                                    ) {
                                        Text(
                                            text = "$num",
                                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                                            style = MaterialTheme.typography.labelLarge,
                                            color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Question 2: Quran & Adhkar switches
                item {
                    LuxuryCard(borderAlpha = 0.3f) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "2. وردك من القرآن والأذكار:",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("هل قرأت شيئاً من القرآن اليوم؟", style = MaterialTheme.typography.bodyMedium)
                                Switch(
                                    checked = quranRead,
                                    onCheckedChange = { quranRead = it },
                                    colors = SwitchDefaults.colors(checkedThumbColor = GoldRadiant)
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("هل حافظت على أذكار الصباح أو المساء؟", style = MaterialTheme.typography.bodyMedium)
                                Switch(
                                    checked = adhkarDone,
                                    onCheckedChange = { adhkarDone = it },
                                    colors = SwitchDefaults.colors(checkedThumbColor = GoldRadiant)
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("هل أكثرت من الاستغفار والتسبيح؟", style = MaterialTheme.typography.bodyMedium)
                                Switch(
                                    checked = istighfarDone,
                                    onCheckedChange = { istighfarDone = it },
                                    colors = SwitchDefaults.colors(checkedThumbColor = GoldRadiant)
                                )
                            }
                        }
                    }
                }

                // Question 3: Ethics & Relationships
                item {
                    LuxuryCard(borderAlpha = 0.3f) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "3. التعامل مع الناس ومراجعة النية:",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("هل تصدقت أو أدخلت سروراً على مسلم؟", style = MaterialTheme.typography.bodyMedium)
                                Switch(
                                    checked = charityDone,
                                    onCheckedChange = { charityDone = it },
                                    colors = SwitchDefaults.colors(checkedThumbColor = GoldRadiant)
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("هل أخطأت في حق أحد ينبغي أن تعتذر له؟", style = MaterialTheme.typography.bodyMedium)
                                Switch(
                                    checked = hurtSomeone,
                                    onCheckedChange = { hurtSomeone = it },
                                    colors = SwitchDefaults.colors(checkedThumbColor = GoldRadiant)
                                )
                            }
                        }
                    }
                }

                // Question 4: Tomorrow's Goal & Notes
                item {
                    LuxuryCard(borderAlpha = 0.3f) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "4. هدف الغد وخاطرة القلب:",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(10.dp))

                            OutlinedTextField(
                                value = tomorrowGoal,
                                onValueChange = { tomorrowGoal = it },
                                label = { Text("عمل صالح أو خطوة طاعة تعزم عليها غداً") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedTextField(
                                value = notes,
                                onValueChange = { notes = it },
                                label = { Text("خواطر وملاحظاتك الشخصية لليلة...") },
                                modifier = Modifier.fillMaxWidth(),
                                maxLines = 3
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            // Peace Rating
                            Text(
                                text = "مستوى طمأنينة وسكينة قلبك اليوم (1 إلى 5):",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                (1..5).forEach { star ->
                                    Icon(
                                        imageVector = Icons.Default.Star,
                                        contentDescription = "تقييم $star",
                                        tint = if (star <= peaceRating) GoldAccent else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                                        modifier = Modifier
                                            .size(32.dp)
                                            .clickable { peaceRating = star }
                                    )
                                }
                            }
                        }
                    }
                }

                // Save Button
                item {
                    Button(
                        onClick = {
                            viewModel.saveMuhasaba(
                                prayersCount = prayersScore,
                                quranRead = quranRead,
                                adhkarDone = adhkarDone,
                                istighfarDone = istighfarDone,
                                charityDone = charityDone,
                                hurtSomeone = hurtSomeone,
                                restitutionNeeded = hurtSomeone,
                                tomorrowGoal = tomorrowGoal,
                                habitToImprove = habitToImprove,
                                personalNotes = notes,
                                peaceRating = peaceRating
                            )
                            isSavedNotification = true
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary
                        )
                    ) {
                        Text(
                            text = if (isSavedNotification) "تم حفظ خلوة الليلة بنجاح ✓" else "حفظ جلسة المحاسبة الليلة",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }
                }
            }
        }
    }
}
