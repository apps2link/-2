package com.example.ui.screens

import android.media.AudioManager
import android.media.ToneGenerator
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.CounterProgressRing
import com.example.ui.components.HapticFeedbackHelper
import com.example.ui.components.LuxuryCard
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldRadiant
import com.example.ui.viewmodel.MainViewModel

@Composable
fun TasbihScreen(viewModel: MainViewModel) {
    val context = LocalContext.current
    val userSettings by viewModel.userSettings.collectAsState()
    val counters by viewModel.tasbihCounters.collectAsState()

    var selectedCounterId by remember { mutableStateOf("subhanallah") }
    val currentCounter = counters.find { it.id == selectedCounterId } ?: counters.firstOrNull()

    var showResetDialog by remember { mutableStateOf(false) }
    var showAddCustomDialog by remember { mutableStateOf(false) }
    var customDhikrText by remember { mutableStateOf("") }
    var customTargetText by remember { mutableStateOf("100") }

    var isPressedAnim by remember { mutableStateOf(false) }
    val buttonScale by animateFloatAsState(
        targetValue = if (isPressedAnim) 0.94f else 1.0f,
        animationSpec = spring(dampingRatio = 0.5f),
        label = "tasbih_button_scale",
        finishedListener = { isPressedAnim = false }
    )

    val count = currentCounter?.count ?: 0
    val target = currentCounter?.target ?: 33
    val totalLifetime = currentCounter?.totalLifetimeCount ?: 0
    val progress = if (target > 0) (count.toFloat() / target.toFloat()).coerceIn(0f, 1f) else 0f

    val targets = listOf(33, 100, 300, 1000)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        // Screen Title
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "السبحة الإلكترونية",
                    style = MaterialTheme.typography.headlineLarge,
                    color = MaterialTheme.colorScheme.onBackground,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "«وَاذْكُر رَّبَّكَ كَثِيرًا وَسَبِّحْ بِالْعَشِيِّ وَالْإِبْكَارِ»",
                    style = MaterialTheme.typography.labelSmall,
                    color = GoldRadiant
                )
            }

            // Custom Dhikr Add button
            IconButton(
                onClick = { showAddCustomDialog = true }
            ) {
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.primaryContainer,
                    border = BorderStroke(1.dp, GoldRadiant.copy(alpha = 0.5f)),
                    modifier = Modifier.size(38.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "إضافة ذكر",
                            tint = GoldRadiant,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Dhikr Presets Selector
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(counters) { counter ->
                val isSelected = counter.id == selectedCounterId
                FilterChip(
                    selected = isSelected,
                    onClick = { selectedCounterId = counter.id },
                    label = {
                        Text(
                            text = counter.titleArabic,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primary,
                        selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    shape = RoundedCornerShape(12.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Current Selected Dhikr Card
        currentCounter?.let {
            LuxuryCard(borderAlpha = 0.4f) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 14.dp, horizontal = 20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = it.titleArabic,
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Center,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "إجمالي تسبيحاتك في هذا الذكر: $totalLifetime",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Target Selector Chips
        Row(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "الهدف:",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            targets.forEach { t ->
                val isCurrentTarget = target == t
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (isCurrentTarget) GoldRadiant else MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, GoldRadiant.copy(alpha = 0.4f)),
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .clickable {
                            currentCounter?.let { viewModel.setTasbihTarget(it.id, t) }
                        }
                ) {
                    Text(
                        text = "$t",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isCurrentTarget) MaterialTheme.colorScheme.background else MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(30.dp))

        // Big Master Digital Misbaha Button & Ring
        CounterProgressRing(
            progress = progress,
            size = 230.dp,
            strokeWidth = 12.dp
        ) {
            Surface(
                modifier = Modifier
                    .size(190.dp)
                    .scale(buttonScale)
                    .clip(CircleShape)
                    .clickable {
                        isPressedAnim = true
                        currentCounter?.let {
                            viewModel.incrementTasbih(it.id)
                            HapticFeedbackHelper.performClick(context, userSettings.hapticFeedbackEnabled)
                            if (userSettings.soundEnabled) {
                                try {
                                    val toneGen = ToneGenerator(AudioManager.STREAM_MUSIC, 40)
                                    toneGen.startTone(ToneGenerator.TONE_PROP_BEEP, 30)
                                } catch (e: Exception) {
                                    // Ignore
                                }
                            }
                            if (count + 1 == target) {
                                HapticFeedbackHelper.performTargetReached(context, userSettings.hapticFeedbackEnabled)
                            }
                        }
                    },
                shape = CircleShape,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(2.dp, GoldRadiant),
                shadowElevation = 8.dp
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "$count",
                        style = MaterialTheme.typography.displayLarge,
                        color = GoldAccent,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 46.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (count >= target) "اكتمل الهدف مباركاً ✓" else "من أصل $target",
                        style = MaterialTheme.typography.labelMedium,
                        color = if (count >= target) GoldRadiant else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(26.dp))

        // Bottom Controls: Reset & Quick Toggles
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Sound toggle
            IconButton(
                onClick = { viewModel.setSoundEnabled(!userSettings.soundEnabled) }
            ) {
                Icon(
                    imageVector = Icons.Default.VolumeUp,
                    contentDescription = "الصوت",
                    tint = if (userSettings.soundEnabled) GoldRadiant else MaterialTheme.colorScheme.outline
                )
            }

            // Reset Button with confirmation
            Button(
                onClick = { showResetDialog = true },
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    contentColor = MaterialTheme.colorScheme.primary
                )
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("تصفير العداد", fontWeight = FontWeight.Bold)
            }

            // Vibration toggle
            IconButton(
                onClick = { viewModel.setHapticEnabled(!userSettings.hapticFeedbackEnabled) }
            ) {
                Icon(
                    imageVector = Icons.Default.Vibration,
                    contentDescription = "الاهتزاز",
                    tint = if (userSettings.hapticFeedbackEnabled) GoldRadiant else MaterialTheme.colorScheme.outline
                )
            }
        }
    }

    // Reset confirmation dialog
    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = { Text("تصفير العداد الحالي؟") },
            text = { Text("هل تود إعادة تعيين عداد «${currentCounter?.titleArabic}» إلى الصفر؟ لن يتم حذف إجمالي تسبيحاتك السابقة.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        currentCounter?.let { viewModel.resetTasbih(it.id) }
                        showResetDialog = false
                    }
                ) {
                    Text("نعم، صفّر العداد", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // Add custom dhikr dialog
    if (showAddCustomDialog) {
        AlertDialog(
            onDismissRequest = { showAddCustomDialog = false },
            title = { Text("إضافة ذكر مخصص للسبحة") },
            text = {
                Column {
                    OutlinedTextField(
                        value = customDhikrText,
                        onValueChange = { customDhikrText = it },
                        label = { Text("نص الذكر أو الدعاء") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = customTargetText,
                        onValueChange = { customTargetText = it },
                        label = { Text("الهدف المطلوب (مثلاً: 100)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (customDhikrText.isNotBlank()) {
                            val targetInt = customTargetText.toIntOrNull() ?: 100
                            viewModel.addCustomTasbih(customDhikrText.trim(), targetInt)
                            showAddCustomDialog = false
                            customDhikrText = ""
                        }
                    }
                ) {
                    Text("إضافة")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddCustomDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}
