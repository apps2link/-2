package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

enum class AppThemeMode(val titleArabic: String, val descriptionArabic: String) {
    EMERALD_GOLD("الزمردي الذهبي", "الهوية الملكية الإسلامية التي تجمع بين الأخضر الزمردي والتذهيب الدافئ"),
    ROYAL_NIGHT("الليلي الملكي", "أجواء سكينة هادئة بالأسود والرمادي الداكن مع تفاصيل مذهبة"),
    SERENE_IVORY("العاجي الهادئ", "مستوحى من الورق الفاخر والمخطوطات العتيقة بألوان نهارية مريحة")
}

// 1. Emerald Gold Scheme
private val EmeraldColorScheme = darkColorScheme(
    primary = GoldRadiant,
    onPrimary = EmeraldDark,
    primaryContainer = EmeraldContainer,
    onPrimaryContainer = GoldLight,
    secondary = GoldAccent,
    onSecondary = EmeraldDark,
    background = EmeraldDark,
    onBackground = CreamParchment,
    surface = EmeraldSurface,
    onSurface = CreamParchment,
    surfaceVariant = EmeraldSurfaceVariant,
    onSurfaceVariant = SandAccent,
    outline = GoldRadiant.copy(alpha = 0.4f),
    outlineVariant = GoldRadiant.copy(alpha = 0.15f)
)

// 2. Royal Night Scheme
private val RoyalNightColorScheme = darkColorScheme(
    primary = RoyalGold,
    onPrimary = RoyalNightBg,
    primaryContainer = RoyalNightCard,
    onPrimaryContainer = RoyalTextPrimary,
    secondary = RoyalGoldSubtle,
    onSecondary = RoyalNightBg,
    background = RoyalNightBg,
    onBackground = RoyalTextPrimary,
    surface = RoyalNightSurface,
    onSurface = RoyalTextPrimary,
    surfaceVariant = RoyalNightCard,
    onSurfaceVariant = RoyalTextSecondary,
    outline = RoyalNightBorder,
    outlineVariant = RoyalGold.copy(alpha = 0.25f)
)

// 3. Serene Ivory Scheme
private val SereneIvoryColorScheme = lightColorScheme(
    primary = IvorySage,
    onPrimary = Color.White,
    primaryContainer = IvoryCard,
    onPrimaryContainer = IvoryText,
    secondary = IvoryAmber,
    onSecondary = Color.White,
    background = IvoryBg,
    onBackground = IvoryText,
    surface = IvorySurface,
    onSurface = IvoryText,
    surfaceVariant = IvoryCard,
    onSurfaceVariant = IvoryTextMuted,
    outline = IvoryAmber.copy(alpha = 0.35f),
    outlineVariant = IvoryAmber.copy(alpha = 0.15f)
)

@Composable
fun UnsiTheme(
    themeMode: AppThemeMode = AppThemeMode.EMERALD_GOLD,
    isDarkSystem: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = when (themeMode) {
        AppThemeMode.EMERALD_GOLD -> EmeraldColorScheme
        AppThemeMode.ROYAL_NIGHT -> RoyalNightColorScheme
        AppThemeMode.SERENE_IVORY -> SereneIvoryColorScheme
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}
