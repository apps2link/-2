package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// ==========================================
// 1. Emerald Gold Palette (الزمردي الذهبي)
// ==========================================
val EmeraldPrimary = Color(0xFF0C4A30)
val EmeraldDark = Color(0xFF062316)
val EmeraldContainer = Color(0xFF13583C)
val EmeraldSurface = Color(0xFF0A2E1F)
val EmeraldSurfaceVariant = Color(0xFF163E2D)

val GoldRadiant = Color(0xFFD4AF37)
val GoldAccent = Color(0xFFFFD700)
val GoldLight = Color(0xFFF7E7A9)
val GoldDark = Color(0xFF997A15)

val CreamParchment = Color(0xFFFAF7F2)
val CreamMuted = Color(0xFFE8E0D0)
val SandAccent = Color(0xFFDFC69A)

// ==========================================
// 2. Royal Night Palette (الليلي الملكي)
// ==========================================
val RoyalNightBg = Color(0xFF090D12)
val RoyalNightSurface = Color(0xFF111821)
val RoyalNightCard = Color(0xFF182230)
val RoyalNightBorder = Color(0xFF26354A)

val RoyalGold = Color(0xFFE5C158)
val RoyalGoldSubtle = Color(0xFFB39237)
val RoyalTextPrimary = Color(0xFFF1F5F9)
val RoyalTextSecondary = Color(0xFF94A3B8)

// ==========================================
// 3. Serene Ivory Palette (العاجي الهادئ)
// ==========================================
val IvoryBg = Color(0xFFFAF8F5)
val IvorySurface = Color(0xFFF2ECE1)
val IvoryCard = Color(0xFFE8DFC0)
val IvorySage = Color(0xFF2A503B)
val IvoryAmber = Color(0xFF966C1E)
val IvoryText = Color(0xFF202621)
val IvoryTextMuted = Color(0xFF5B695E)

// Universal Status & Overlay Colors
val IslamicGreen = Color(0xFF1B8A5A)
val GlowGold = Color(0x33FFD700)
val GlowEmerald = Color(0x330C4A30)
val StarWhite = Color(0xFFFFFFFF)
val MutedDivider = Color(0x26D4AF37)
