package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.AudioPlayerManager
import com.example.data.local.UnsiDatabase
import com.example.data.local.UserPreferencesRepository
import com.example.data.local.UserSettings
import com.example.data.local.entity.DhikrProgressEntity
import com.example.data.local.entity.FavoriteEntity
import com.example.data.local.entity.MuhasabaEntity
import com.example.data.local.entity.PrayerRecordEntity
import com.example.data.local.entity.TasbihCounterEntity
import com.example.data.model.CompanionChatMessage
import com.example.data.model.CompanionRecommendation
import com.example.data.model.DailyPrayerTimes
import com.example.data.repository.CompanionRepository
import com.example.data.repository.PrayerTimesCalculator
import com.example.ui.theme.AppThemeMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = UnsiDatabase.getDatabase(application)
    private val dao = db.unsiDao()
    val prefsRepo = UserPreferencesRepository(application)
    val audioPlayer = AudioPlayerManager(application)

    val todayDateString: String
        get() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    val userSettings: StateFlow<UserSettings> = prefsRepo.userSettingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserSettings())

    val favorites: StateFlow<List<FavoriteEntity>> = dao.getAllFavorites()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val prayerRecord: StateFlow<PrayerRecordEntity?> = dao.getPrayerRecord(todayDateString)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val muhasabaRecord: StateFlow<MuhasabaEntity?> = dao.getMuhasabaByDate(todayDateString)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val allMuhasabaHistory: StateFlow<List<MuhasabaEntity>> = dao.getAllMuhasaba()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val tasbihCounters: StateFlow<List<TasbihCounterEntity>> = dao.getAllTasbihCounters()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val dhikrProgressList: StateFlow<List<DhikrProgressEntity>> = dao.getAllDhikrProgress()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Prayer times state
    private val _dailyPrayerTimes = MutableStateFlow(
        PrayerTimesCalculator.calculatePrayerTimes(21.4225, 39.8262)
    )
    val dailyPrayerTimes: StateFlow<DailyPrayerTimes> = _dailyPrayerTimes.asStateFlow()

    // Companion recommendation & Chat state
    private val _companionRecommendation = MutableStateFlow(CompanionRepository.getCurrentContextRecommendation())
    val companionRecommendation: StateFlow<CompanionRecommendation> = _companionRecommendation.asStateFlow()

    private val _chatMessages = MutableStateFlow<List<CompanionChatMessage>>(
        listOf(
            CompanionChatMessage(
                id = "init_1",
                isFromCompanion = true,
                text = "السلام عليكم ورحمة الله وبركاته. أنا «رفيق أُنسي»، رفيقك اليومي إلى طاعة الله وذكره. كيف أستطيع إعانتك اليوم؟",
                actionButtonText = "اقتراح ورد اليوم",
                actionRoute = "wird_plan"
            )
        )
    )
    val chatMessages: StateFlow<List<CompanionChatMessage>> = _chatMessages.asStateFlow()

    init {
        viewModelScope.launch {
            userSettings.collect { settings ->
                _dailyPrayerTimes.value = PrayerTimesCalculator.calculatePrayerTimes(
                    settings.latitude,
                    settings.longitude
                )
            }
        }
        initDefaultTasbihCounters()
    }

    private fun initDefaultTasbihCounters() {
        viewModelScope.launch {
            val existing = dao.getTasbihCounterDirect("subhanallah")
            if (existing == null) {
                dao.upsertTasbihCounter(
                    TasbihCounterEntity("subhanallah", "سُبْحَانَ اللَّهِ", 0, 33, 0)
                )
                dao.upsertTasbihCounter(
                    TasbihCounterEntity("alhamdulillah", "الْحَمْدُ لِلَّهِ", 0, 33, 0)
                )
                dao.upsertTasbihCounter(
                    TasbihCounterEntity("allahuakbar", "اللَّهُ أَكْبَرُ", 0, 33, 0)
                )
                dao.upsertTasbihCounter(
                    TasbihCounterEntity("istighfar", "أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ", 0, 100, 0)
                )
                dao.upsertTasbihCounter(
                    TasbihCounterEntity("salawat", "اللَّهُمَّ صَلِّ عَلَى نَبِيِّنَا مُحَمَّدٍ", 0, 100, 0)
                )
                dao.upsertTasbihCounter(
                    TasbihCounterEntity("hawqala", "لا حَوْلَ وَلا قُوَّةَ إِلا بِاللَّهِ", 0, 100, 0)
                )
            }
        }
    }

    // --- Tasbih Actions ---
    fun incrementTasbih(id: String) {
        viewModelScope.launch {
            val counter = dao.getTasbihCounterDirect(id) ?: return@launch
            val newCount = counter.count + 1
            dao.upsertTasbihCounter(
                counter.copy(
                    count = newCount,
                    totalLifetimeCount = counter.totalLifetimeCount + 1,
                    lastUpdated = System.currentTimeMillis()
                )
            )
        }
    }

    fun resetTasbih(id: String) {
        viewModelScope.launch {
            val counter = dao.getTasbihCounterDirect(id) ?: return@launch
            dao.upsertTasbihCounter(counter.copy(count = 0))
        }
    }

    fun setTasbihTarget(id: String, target: Int) {
        viewModelScope.launch {
            val counter = dao.getTasbihCounterDirect(id) ?: return@launch
            dao.upsertTasbihCounter(counter.copy(target = target))
        }
    }

    fun addCustomTasbih(titleArabic: String, target: Int) {
        viewModelScope.launch {
            val id = "custom_" + System.currentTimeMillis()
            dao.upsertTasbihCounter(
                TasbihCounterEntity(id, titleArabic, 0, target, 0)
            )
        }
    }

    // --- Dhikr Progress Actions ---
    fun incrementDhikrProgress(dhikrId: String, targetCount: Int) {
        viewModelScope.launch {
            val existing = dhikrProgressList.value.find { it.dhikrId == dhikrId }
            val current = existing?.currentCount ?: 0
            val newCount = (current + 1).coerceAtMost(targetCount)
            dao.upsertDhikrProgress(
                DhikrProgressEntity(
                    dhikrId = dhikrId,
                    currentCount = newCount,
                    targetCount = targetCount,
                    isCompleted = (newCount >= targetCount),
                    lastCompletedDate = todayDateString,
                    lastUpdated = System.currentTimeMillis()
                )
            )
        }
    }

    fun resetDhikrProgress(dhikrId: String, targetCount: Int) {
        viewModelScope.launch {
            dao.upsertDhikrProgress(
                DhikrProgressEntity(
                    dhikrId = dhikrId,
                    currentCount = 0,
                    targetCount = targetCount,
                    isCompleted = false,
                    lastCompletedDate = todayDateString
                )
            )
        }
    }

    // --- Prayer Completion Actions ---
    fun togglePrayer(prayerName: String) {
        viewModelScope.launch {
            val current = prayerRecord.value ?: PrayerRecordEntity(date = todayDateString)
            val updated = when (prayerName) {
                "fajr" -> current.copy(fajrDone = !current.fajrDone)
                "dhuhr" -> current.copy(dhuhrDone = !current.dhuhrDone)
                "asr" -> current.copy(asrDone = !current.asrDone)
                "maghrib" -> current.copy(maghribDone = !current.maghribDone)
                "isha" -> current.copy(ishaDone = !current.ishaDone)
                else -> current
            }
            dao.upsertPrayerRecord(updated)
        }
    }

    // --- Favorites Actions ---
    fun toggleFavorite(id: String, type: String, title: String, content: String, ref: String) {
        viewModelScope.launch {
            val isFav = favorites.value.any { it.id == id }
            if (isFav) {
                dao.deleteFavoriteById(id)
            } else {
                dao.insertFavorite(
                    FavoriteEntity(
                        id = id,
                        type = type,
                        title = title,
                        contentArabic = content,
                        reference = ref
                    )
                )
            }
        }
    }

    // --- Muhasaba Actions ---
    fun saveMuhasaba(
        prayersCount: Int,
        quranRead: Boolean,
        adhkarDone: Boolean,
        istighfarDone: Boolean,
        charityDone: Boolean,
        hurtSomeone: Boolean,
        restitutionNeeded: Boolean,
        tomorrowGoal: String,
        habitToImprove: String,
        personalNotes: String,
        peaceRating: Int
    ) {
        viewModelScope.launch {
            dao.upsertMuhasaba(
                MuhasabaEntity(
                    date = todayDateString,
                    prayersCompletedCount = prayersCount,
                    quranRead = quranRead,
                    adhkarDone = adhkarDone,
                    istighfarDone = istighfarDone,
                    charityDone = charityDone,
                    hurtSomeone = hurtSomeone,
                    restitutionNeeded = restitutionNeeded,
                    tomorrowGoal = tomorrowGoal,
                    habitToImprove = habitToImprove,
                    personalNotes = personalNotes,
                    peaceRating = peaceRating
                )
            )
        }
    }

    // --- Companion Chat ---
    fun sendCompanionMessage(text: String) {
        if (text.isBlank()) return
        val userMsg = CompanionChatMessage(
            id = System.currentTimeMillis().toString(),
            isFromCompanion = false,
            text = text
        )
        val reply = CompanionRepository.generateReply(text)
        _chatMessages.value = _chatMessages.value + userMsg + reply
    }

    // --- Settings & Customization ---
    fun setThemeMode(mode: AppThemeMode) {
        viewModelScope.launch { prefsRepo.setThemeMode(mode) }
    }

    fun setFontSizeScale(scale: Float) {
        viewModelScope.launch { prefsRepo.setFontSizeScale(scale) }
    }

    fun setHapticEnabled(enabled: Boolean) {
        viewModelScope.launch { prefsRepo.setHapticEnabled(enabled) }
    }

    fun setSoundEnabled(enabled: Boolean) {
        viewModelScope.launch { prefsRepo.setSoundEnabled(enabled) }
    }

    fun setAmbientEnabled(enabled: Boolean) {
        viewModelScope.launch { prefsRepo.setAmbientEnabled(enabled) }
    }

    fun setCompanionReminders(enabled: Boolean) {
        viewModelScope.launch { prefsRepo.setCompanionReminders(enabled) }
    }

    fun setCity(city: String, lat: Double, lng: Double) {
        viewModelScope.launch { prefsRepo.setCity(city, lat, lng) }
    }

    fun setDailyTargets(tasbih: Int, quranPages: Int) {
        viewModelScope.launch { prefsRepo.setDailyTargets(tasbih, quranPages) }
    }

    fun setFirstLaunchCompleted() {
        viewModelScope.launch { prefsRepo.setFirstLaunchCompleted(true) }
    }

    fun saveLastReadingPosition(surahNum: Int, surahName: String, ayahNum: Int, page: Int) {
        viewModelScope.launch {
            prefsRepo.saveLastReadingPosition(surahNum, surahName, ayahNum, page)
        }
    }

    fun clearAllUserData() {
        viewModelScope.launch {
            dao.clearFavorites()
            dao.clearMuhasaba()
            dao.clearPrayerRecords()
            dao.clearDhikrProgress()
            prefsRepo.clearAllPreferences()
            initDefaultTasbihCounters()
        }
    }

    override fun onCleared() {
        super.onCleared()
        audioPlayer.release()
    }
}
