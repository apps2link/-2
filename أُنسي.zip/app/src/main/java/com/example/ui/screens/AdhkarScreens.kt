package com.example.ui.screens

import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DhikrItem
import com.example.data.repository.AdhkarRepository
import com.example.ui.components.CounterProgressRing
import com.example.ui.components.HapticFeedbackHelper
import com.example.ui.components.LuxuryCard
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldRadiant
import com.example.ui.viewmodel.MainViewModel

@Composable
fun AdhkarCategoriesScreen(
    onCategoryClick: (String) -> Unit,
    onSearchClick: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val categories = AdhkarRepository.categories

    val filtered = if (searchQuery.isBlank()) {
        categories
    } else {
        categories.filter {
            AdhkarRepository.normalizeArabic(it.titleArabic)
                .contains(AdhkarRepository.normalizeArabic(searchQuery)) ||
                    AdhkarRepository.normalizeArabic(it.descriptionArabic)
                        .contains(AdhkarRepository.normalizeArabic(searchQuery))
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "مكتبة الأذكار والأدعية",
            style = MaterialTheme.typography.headlineLarge,
            color = MaterialTheme.colorScheme.onBackground,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "أدعية وأذكار موثقة من الكتاب والسنة المطهرة",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("ابحث في أقسام الأذكار والأدعية...") },
            leadingIcon = {
                Icon(Icons.Default.Search, contentDescription = null, tint = GoldRadiant)
            },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { searchQuery = "" }) {
                        Icon(Icons.Default.Clear, contentDescription = "مسح")
                    }
                }
            },
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = GoldRadiant,
                unfocusedBorderColor = MaterialTheme.colorScheme.outline
            ),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 100.dp)
        ) {
            items(filtered) { category ->
                LuxuryCard(
                    onClick = { onCategoryClick(category.id) },
                    borderAlpha = 0.35f
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.size(46.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = category.count.toString(),
                                    style = MaterialTheme.typography.titleMedium,
                                    color = GoldRadiant,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = category.titleArabic,
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onBackground,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = category.descriptionArabic,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 2
                            )
                        }

                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = null,
                            tint = GoldRadiant.copy(alpha = 0.7f),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun DhikrCategoryListScreen(
    categoryId: String,
    viewModel: MainViewModel,
    onBack: () -> Unit,
    onDhikrClick: (String) -> Unit
) {
    val context = LocalContext.current
    val userSettings by viewModel.userSettings.collectAsState()
    val favorites by viewModel.favorites.collectAsState()
    val progressList by viewModel.dhikrProgressList.collectAsState()

    val category = AdhkarRepository.categories.find { it.id == categoryId }
    val dhikrItems = AdhkarRepository.getDhikrByCategory(categoryId)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "رجوع",
                    tint = MaterialTheme.colorScheme.onBackground
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = category?.titleArabic ?: "الأذكار",
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${dhikrItems.size} أذكار موثقة",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(bottom = 100.dp)
        ) {
            items(dhikrItems) { item ->
                val progress = progressList.find { it.dhikrId == item.id }
                val currentCount = progress?.currentCount ?: 0
                val isDone = progress?.isCompleted == true || currentCount >= item.repeatTarget
                val isFav = favorites.any { it.id == item.id }

                LuxuryCard(
                    onClick = { onDhikrClick(item.id) },
                    borderAlpha = if (isDone) 0.6f else 0.35f
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp)
                    ) {
                        // Text
                        Text(
                            text = item.textArabic,
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurface,
                            lineHeight = 28.sp,
                            fontWeight = FontWeight.Medium
                        )

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = item.fadilah,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "[${item.reference}]",
                            style = MaterialTheme.typography.labelSmall,
                            color = GoldRadiant
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // Controls Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Tap to repeat button
                            Button(
                                onClick = {
                                    if (currentCount < item.repeatTarget) {
                                        viewModel.incrementDhikrProgress(item.id, item.repeatTarget)
                                        HapticFeedbackHelper.performClick(context, userSettings.hapticFeedbackEnabled)
                                        if (currentCount + 1 >= item.repeatTarget) {
                                            HapticFeedbackHelper.performTargetReached(context, userSettings.hapticFeedbackEnabled)
                                        }
                                    } else {
                                        viewModel.resetDhikrProgress(item.id, item.repeatTarget)
                                    }
                                },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isDone) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.primary,
                                    contentColor = if (isDone) GoldRadiant else MaterialTheme.colorScheme.onPrimary
                                )
                            ) {
                                if (isDone) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = GoldRadiant,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("تم (${item.repeatTarget}/${item.repeatTarget}) ↻")
                                } else {
                                    Text("تكرار: $currentCount / ${item.repeatTarget}")
                                }
                            }

                            Row {
                                IconButton(
                                    onClick = {
                                        viewModel.toggleFavorite(
                                            id = item.id,
                                            type = "DHIKR",
                                            title = item.categoryArabic,
                                            content = item.textArabic,
                                            ref = item.reference
                                        )
                                        HapticFeedbackHelper.performClick(context, userSettings.hapticFeedbackEnabled)
                                    }
                                ) {
                                    Icon(
                                        imageVector = if (isFav) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                                        contentDescription = "المفضلة",
                                        tint = if (isFav) GoldRadiant else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                IconButton(
                                    onClick = {
                                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                            type = "text/plain"
                                            putExtra(
                                                Intent.EXTRA_TEXT,
                                                "«${item.textArabic}»\n\nفضله: ${item.fadilah}\nالمصدر: ${item.reference}\n\nعبر تطبيق «أُنسي» - رفيقك إلى الله."
                                            )
                                        }
                                        context.startActivity(Intent.createChooser(shareIntent, "مشاركة الذكر"))
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Share,
                                        contentDescription = "مشاركة",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DhikrDetailScreen(
    dhikrId: String,
    viewModel: MainViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val userSettings by viewModel.userSettings.collectAsState()
    val progressList by viewModel.dhikrProgressList.collectAsState()
    val favorites by viewModel.favorites.collectAsState()

    val item = AdhkarRepository.getDhikrById(dhikrId) ?: AdhkarRepository.getDailyDhikr()
    val progress = progressList.find { it.dhikrId == item.id }
    val count = progress?.currentCount ?: 0
    val target = item.repeatTarget
    val isDone = count >= target
    val isFav = favorites.any { it.id == item.id }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        // Top bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "رجوع",
                    tint = MaterialTheme.colorScheme.onBackground
                )
            }

            Text(
                text = item.categoryArabic,
                style = MaterialTheme.typography.titleMedium,
                color = GoldRadiant,
                fontWeight = FontWeight.Bold
            )

            IconButton(
                onClick = {
                    viewModel.toggleFavorite(
                        id = item.id,
                        type = "DHIKR",
                        title = item.categoryArabic,
                        content = item.textArabic,
                        ref = item.reference
                    )
                    HapticFeedbackHelper.performClick(context, userSettings.hapticFeedbackEnabled)
                }
            ) {
                Icon(
                    imageVector = if (isFav) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                    contentDescription = "المفضلة",
                    tint = if (isFav) GoldRadiant else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Large Dhikr Text Card
        LuxuryCard(borderAlpha = 0.5f) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = item.textArabic,
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    textAlign = TextAlign.Center,
                    lineHeight = 36.sp,
                    fontWeight = FontWeight.SemiBold
                )

                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = item.fadilah,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "[${item.reference}]",
                    style = MaterialTheme.typography.labelMedium,
                    color = GoldRadiant,
                    textAlign = TextAlign.Center
                )
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        // Large Interactive Pulse Ring & Tap Area
        CounterProgressRing(
            progress = if (target > 0) count.toFloat() / target.toFloat() else 0f,
            size = 180.dp,
            strokeWidth = 10.dp
        ) {
            Surface(
                modifier = Modifier
                    .size(150.dp)
                    .clip(CircleShape)
                    .clickable {
                        if (count < target) {
                            viewModel.incrementDhikrProgress(item.id, target)
                            HapticFeedbackHelper.performClick(context, userSettings.hapticFeedbackEnabled)
                            if (count + 1 >= target) {
                                HapticFeedbackHelper.performTargetReached(context, userSettings.hapticFeedbackEnabled)
                            }
                        } else {
                            viewModel.resetDhikrProgress(item.id, target)
                            HapticFeedbackHelper.performClick(context, userSettings.hapticFeedbackEnabled)
                        }
                    },
                shape = CircleShape,
                color = if (isDone) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.5.dp, GoldRadiant)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "$count",
                        style = MaterialTheme.typography.displayLarge,
                        color = GoldAccent,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (isDone) "اكتمل الورد ✓" else "من $target",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Reset Counter Button
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center
        ) {
            IconButton(
                onClick = {
                    viewModel.resetDhikrProgress(item.id, target)
                    HapticFeedbackHelper.performClick(context, userSettings.hapticFeedbackEnabled)
                }
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "إعادة العداد",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
