package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.AdhkarRepository
import com.example.data.repository.QuranRepository
import com.example.notification.ReminderReceiver
import com.example.ui.components.LuxuryCard
import com.example.ui.components.SectionHeader
import com.example.ui.theme.AppThemeMode
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldRadiant
import com.example.ui.viewmodel.MainViewModel

// 1. Favorites Screen (المفضلة)
@Composable
fun FavoritesScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val favorites by viewModel.favorites.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "رجوع",
                    tint = MaterialTheme.colorScheme.onBackground
                )
            }
            Text(
                text = "المفضلة والمحفوظات",
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onBackground,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.size(40.dp))
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (favorites.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = 80.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Bookmark,
                        contentDescription = null,
                        tint = GoldRadiant.copy(alpha = 0.4f),
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "لا توجد عناصر محفوظة حتى الآن",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "يمكنك حفظ الأذكار والآيات المفضلة بالضغط على علامة الحفظ",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 90.dp)
            ) {
                items(favorites) { fav ->
                    LuxuryCard(borderAlpha = 0.35f) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f)
                                ) {
                                    Text(
                                        text = if (fav.type == "AYAH") "📖 آية قرآنية" else "✨ ذكر محفوظ",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = GoldRadiant,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                    )
                                }

                                Row {
                                    IconButton(
                                        onClick = {
                                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                                type = "text/plain"
                                                putExtra(Intent.EXTRA_TEXT, "«${fav.contentArabic}»\n[${fav.reference}]\nعبر تطبيق «أُنسي»")
                                            }
                                            context.startActivity(Intent.createChooser(shareIntent, "مشاركة"))
                                        }
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Share,
                                            contentDescription = "مشاركة",
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }

                                    IconButton(
                                        onClick = {
                                            viewModel.toggleFavorite(fav.id, fav.type, fav.title, fav.contentArabic, fav.reference)
                                        }
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Delete,
                                            contentDescription = "حذف من المفضلة",
                                            tint = MaterialTheme.colorScheme.error,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = fav.contentArabic,
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurface,
                                lineHeight = 26.sp
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "[${fav.reference}]",
                                style = MaterialTheme.typography.labelSmall,
                                color = GoldRadiant
                            )
                        }
                    }
                }
            }
        }
    }
}

// 2. Search Screen (البحث الموحد)
@Composable
fun SearchScreen(
    viewModel: MainViewModel,
    onDhikrClick: (String) -> Unit,
    onSurahClick: (Int) -> Unit,
    onBack: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    val adhkarResults = AdhkarRepository.searchDhikr(query)
    val surahResults = if (query.isNotBlank()) QuranRepository.searchSurahs(query) else emptyList()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "رجوع",
                    tint = MaterialTheme.colorScheme.onBackground
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("ابحث عن أي ذكر أو سورة أو دعاء...") },
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = GoldRadiant,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline
                ),
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { query = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "مسح")
                        }
                    }
                },
                singleLine = true
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (query.isBlank()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = 80.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "اكتب كلمة للبحث الفوري دون الحاجة إلى اتصال بالإنترنت",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 90.dp)
            ) {
                if (surahResults.isNotEmpty()) {
                    item {
                        Text(
                            text = "السور القرآنية المطابقة (${surahResults.size}):",
                            style = MaterialTheme.typography.titleSmall,
                            color = GoldRadiant,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    items(surahResults) { surah ->
                        LuxuryCard(onClick = { onSurahClick(surah.number) }) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "سورة ${surah.nameArabic} (${surah.number})",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${surah.versesCount} آيات • جزء ${surah.juzStart}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                if (adhkarResults.isNotEmpty()) {
                    item {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "الأذكار والأدعية المطابقة (${adhkarResults.size}):",
                            style = MaterialTheme.typography.titleSmall,
                            color = GoldRadiant,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    items(adhkarResults) { item ->
                        LuxuryCard(onClick = { onDhikrClick(item.id) }) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text(
                                    text = item.textArabic,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    lineHeight = 22.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "${item.categoryArabic} • [${item.reference}]",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = GoldRadiant
                                )
                            }
                        }
                    }
                }

                if (surahResults.isEmpty() && adhkarResults.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 40.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "لم يتم العثور على نتائج تطابق «$query»",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

// 3. Customization & Themes Screen (مركز التخصيص والثيمات)
@Composable
fun CustomizationScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit
) {
    val userSettings by viewModel.userSettings.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "رجوع",
                    tint = MaterialTheme.colorScheme.onBackground
                )
            }
            Text(
                text = "مركز التخصيص والثيمات",
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onBackground,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.size(40.dp))
        }

        Spacer(modifier = Modifier.height(18.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(bottom = 90.dp)
        ) {
            // Theme Mode Selector (3 Distinct Themes)
            item {
                SectionHeader(title = "الثيم البصري", subtitle = "اختر الهوية البصرية المفضلة لديك", icon = Icons.Default.ColorLens)

                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    AppThemeMode.entries.forEach { mode ->
                        val isSelected = userSettings.themeMode == mode
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .clickable { viewModel.setThemeMode(mode) },
                            shape = RoundedCornerShape(16.dp),
                            color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                            border = BorderStroke(
                                1.5.dp,
                                if (isSelected) GoldRadiant else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = if (isSelected) GoldRadiant else MaterialTheme.colorScheme.surfaceVariant,
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    if (isSelected) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Text("✓", color = MaterialTheme.colorScheme.background, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.width(14.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = mode.titleArabic,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = mode.descriptionArabic,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Visual Effects & Ambiance
            item {
                SectionHeader(title = "المؤثرات والأنيميشن", subtitle = "التحكم في حركة الزخارف وتوفير الطاقة")

                LuxuryCard(borderAlpha = 0.3f) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "الزخارف الإسلامية الحية الهادئة",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "حركة لطيفة للنجوم والأقواس الهندسية في الخلفية",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(
                                checked = userSettings.ambientDecorationsEnabled,
                                onCheckedChange = { viewModel.setAmbientEnabled(it) },
                                colors = SwitchDefaults.colors(checkedThumbColor = GoldRadiant)
                            )
                        }
                    }
                }
            }

            // Tactile & Audio Preferences
            item {
                SectionHeader(title = "الصوت والاهتزاز", subtitle = "التغذية الراجعة التفاعلية أثناء التسبيح")

                LuxuryCard(borderAlpha = 0.3f) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("الاهتزاز اللمسي أثناء التسبيح", style = MaterialTheme.typography.bodyMedium)
                            Switch(
                                checked = userSettings.hapticFeedbackEnabled,
                                onCheckedChange = { viewModel.setHapticEnabled(it) },
                                colors = SwitchDefaults.colors(checkedThumbColor = GoldRadiant)
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("الصوت الخفيف عند الضغط", style = MaterialTheme.typography.bodyMedium)
                            Switch(
                                checked = userSettings.soundEnabled,
                                onCheckedChange = { viewModel.setSoundEnabled(it) },
                                colors = SwitchDefaults.colors(checkedThumbColor = GoldRadiant)
                            )
                        }
                    }
                }
            }
        }
    }
}

// 4. Widget Guide Screen (دليل ويدجات أندرويد)
@Composable
fun WidgetGuideScreen(onBack: () -> Unit) {
    val widgetList = listOf(
        Pair("سبحة أُنسي", "عداد تسبيح مباشر مع زر +1 للتسبيح السريع من الشاشة الرئيسية"),
        Pair("الصلاة القادمة", "اسم الصلاة القادمة والوقت المتبقي مع تحديث تلقائي"),
        Pair("ذكر اللحظة", "ذكر مختار متجدد مع زر للتنقل بين الأذكار مباشرة"),
        Pair("وردي اليومي", "مؤشر تقدم الأذكار والقرآن ومتابعة الصلوات الخمس"),
        Pair("آية اليوم", "آية قرآنية موثوقة مع اسم السورة ورقم الآية يومياً"),
        Pair("محاسبة النفس", "تذكير بخلوة أُنسي المسائية وحالة إكمالها")
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "رجوع",
                    tint = MaterialTheme.colorScheme.onBackground
                )
            }
            Text(
                text = "ويدجات أُنسي الحقيقية",
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onBackground,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.size(40.dp))
        }

        Spacer(modifier = Modifier.height(14.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(bottom = 90.dp)
        ) {
            item {
                LuxuryCard(borderAlpha = 0.5f) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = "كيف تضيف ويدجات أُنسي إلى شاشة هاتفك؟",
                            style = MaterialTheme.typography.titleMedium,
                            color = GoldAccent,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "1. اخرج إلى الشاشة الرئيسية لهاتفك.\n2. اضغط مطولاً في أي مساحة فارغة.\n3. اختر «التطبيقات المصغرة / Widgets» من القائمة.\n4. ابحث عن تطبيق «أُنسي».\n5. اختر الويدجت المفضلة واسحبها إلى شاشتك.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                            lineHeight = 24.sp
                        )
                    }
                }
            }

            item {
                Text(
                    text = "الويدجات الـ 6 المتاحة في التطبيق:",
                    style = MaterialTheme.typography.titleSmall,
                    color = GoldRadiant,
                    fontWeight = FontWeight.Bold
                )
            }

            items(widgetList) { w ->
                LuxuryCard(borderAlpha = 0.35f) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.size(40.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Widgets, contentDescription = null, tint = GoldRadiant)
                            }
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column {
                            Text(
                                text = w.first,
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = w.second,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

// 5. Settings Screen (الإعدادات والخصوصية)
@Composable
fun SettingsScreen(
    viewModel: MainViewModel,
    onNavigateToCustomization: () -> Unit,
    onNavigateToWidgets: () -> Unit,
    onNavigateToStats: () -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val userSettings by viewModel.userSettings.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "رجوع",
                    tint = MaterialTheme.colorScheme.onBackground
                )
            }
            Text(
                text = "الإعدادات والخصوصية",
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onBackground,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.size(40.dp))
        }

        Spacer(modifier = Modifier.height(18.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(bottom = 90.dp)
        ) {
            // Quick Links
            item {
                LuxuryCard(onClick = onNavigateToCustomization) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.ColorLens, contentDescription = null, tint = GoldRadiant)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text("الثيمات والتخصيص والمظهر", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        }
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = GoldRadiant)
                    }
                }
            }

            item {
                LuxuryCard(onClick = onNavigateToWidgets) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Widgets, contentDescription = null, tint = GoldRadiant)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text("دليل ويدجات الشاشة الرئيسية", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        }
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = GoldRadiant)
                    }
                }
            }

            item {
                LuxuryCard(onClick = onNavigateToStats) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Info, contentDescription = null, tint = GoldRadiant)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text("سجل الإحصائيات وإدارة البيانات", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        }
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = GoldRadiant)
                    }
                }
            }

            // Notifications
            item {
                SectionHeader(title = "التذكيرات والإشعارات", subtitle = "تفعيل إشعارات الأذكار اليومية", icon = Icons.Default.Notifications)

                LuxuryCard(borderAlpha = 0.35f) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("تذكيرات رفيق أُنسي الإيمانية", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                Text("تنبيهات أذكار الصباح والمساء وخلوة المحاسبة", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Switch(
                                checked = userSettings.companionReminderEnabled,
                                onCheckedChange = { viewModel.setCompanionReminders(it) },
                                colors = SwitchDefaults.colors(checkedThumbColor = GoldRadiant)
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Button(
                            onClick = {
                                ReminderReceiver.showNotification(
                                    context,
                                    "✨ تذكير أُنسي الإيماني",
                                    "ألا بذكر الله تطمئن القلوب. خذ دقيقة لتسبيح الله وحمده.",
                                    "GENERAL"
                                )
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primaryContainer,
                                contentColor = MaterialTheme.colorScheme.primary
                            ),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("إرسال تجربة إشعار تذكيري")
                        }
                    }
                }
            }

            // Privacy Pledge (الخصوصية والأمان)
            item {
                SectionHeader(title = "الخصوصية والعمل دون إنترنت", subtitle = "مبدأ Offline-First والأمان التام", icon = Icons.Default.Security)

                LuxuryCard(borderAlpha = 0.35f) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = "عهد أُنسي للخصوصية:",
                            style = MaterialTheme.typography.titleSmall,
                            color = GoldAccent,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "• التطبيق يعمل بالكامل دون الحاجة إلى اتصال بالإنترنت في مكتبة الأذكار، السبحة، القرآن، مواقيت الصلاة، والمحاسبة.\n• خلوات محاسبة النفس والملاحظات الشخصية محفوظة محلياً على هاتفك حصراً ولا تُرسل لأي جهة أو خادم خارجي.\n• لا نطلب تسجيل حساب ولا نجمع بيانات شخصية إطلاقاً.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface,
                            lineHeight = 22.sp
                        )
                    }
                }
            }

            // About UNSI
            item {
                LuxuryCard(borderAlpha = 0.3f) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "تطبيق «أُنسي» • الإصدار 1.0",
                            style = MaterialTheme.typography.titleMedium,
                            color = GoldRadiant,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "«رفيقك إلى الله»\nاجعل ذكر الله جزءاً حياً من يومك، وليس مجرد تطبيق تفتحه ثم تنساه.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
    }
}

// 6. Onboarding Screen (شاشة أول تشغيل)
@Composable
fun OnboardingScreen(
    viewModel: MainViewModel,
    onFinish: () -> Unit
) {
    val userSettings by viewModel.userSettings.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(modifier = Modifier.height(30.dp))

            Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primaryContainer,
                border = BorderStroke(2.dp, GoldRadiant),
                modifier = Modifier.size(90.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text("✨", fontSize = 40.sp)
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "مرحباً بك في «أُنسي»",
                style = MaterialTheme.typography.displayMedium,
                color = GoldRadiant,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "رفيقك اليومي إلى طاعة الله وذكره",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onBackground
            )

            Spacer(modifier = Modifier.height(26.dp))

            LuxuryCard(borderAlpha = 0.4f) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "اختر الثيم الأولي لتجربتك:",
                        style = MaterialTheme.typography.titleSmall,
                        color = GoldAccent,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    AppThemeMode.entries.forEach { mode ->
                        val isSelected = userSettings.themeMode == mode
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .clickable { viewModel.setThemeMode(mode) },
                            shape = RoundedCornerShape(10.dp),
                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, GoldRadiant.copy(alpha = if (isSelected) 0.8f else 0.3f))
                        ) {
                            Text(
                                text = mode.titleArabic,
                                style = MaterialTheme.typography.labelMedium,
                                color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(10.dp),
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            }
        }

        Button(
            onClick = {
                viewModel.setFirstLaunchCompleted()
                onFinish()
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            )
        ) {
            Text(
                text = "ابدأ رحلتك الإيمانية مع أُنسي ←",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
