package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Mosque
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.CounterProgressRing
import com.example.ui.components.LuxuryCard
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldRadiant
import com.example.ui.viewmodel.MainViewModel

// 1. Daily Wird Plan Screen (وردي اليومي)
@Composable
fun WirdPlanScreen(
    viewModel: MainViewModel,
    onNavigate: (String) -> Unit,
    onBack: () -> Unit
) {
    val userSettings by viewModel.userSettings.collectAsState()
    val progressList by viewModel.dhikrProgressList.collectAsState()
    val prayerRecord by viewModel.prayerRecord.collectAsState()
    val muhasabaRecord by viewModel.muhasabaRecord.collectAsState()
    val tasbihCounters by viewModel.tasbihCounters.collectAsState()

    var showEditGoalsDialog by remember { mutableStateOf(false) }
    var editTasbihText by remember { mutableStateOf(userSettings.dailyTasbihTarget.toString()) }
    var editQuranText by remember { mutableStateOf(userSettings.dailyQuranPagesTarget.toString()) }

    // Computations
    val totalTasbihToday = tasbihCounters.sumOf { it.count }
    val tasbihProgress = (totalTasbihToday.toFloat() / userSettings.dailyTasbihTarget.toFloat()).coerceIn(0f, 1f)

    var completedPrayers = 0
    if (prayerRecord?.fajrDone == true) completedPrayers++
    if (prayerRecord?.dhuhrDone == true) completedPrayers++
    if (prayerRecord?.asrDone == true) completedPrayers++
    if (prayerRecord?.maghribDone == true) completedPrayers++
    if (prayerRecord?.ishaDone == true) completedPrayers++
    val prayerProgress = (completedPrayers / 5f).coerceIn(0f, 1f)

    val completedDhikrCount = progressList.count { it.isCompleted }
    val dhikrProgress = (completedDhikrCount.toFloat() / 5f).coerceIn(0f, 1f)

    val overallScore = ((tasbihProgress + prayerProgress + dhikrProgress + if (muhasabaRecord != null) 1f else 0f) / 4f)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        // Top Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "رجوع",
                    tint = MaterialTheme.colorScheme.onBackground
                )
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "خطة الورد اليومي",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onBackground,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "«أَحَبُّ الأَعْمَالِ إِلَى اللَّهِ أَدْوَمُهَا وَإِنْ قَلَّ»",
                    style = MaterialTheme.typography.labelSmall,
                    color = GoldRadiant
                )
            }

            IconButton(onClick = { showEditGoalsDialog = true }) {
                Icon(
                    imageVector = Icons.Default.Edit,
                    contentDescription = "تعديل الأهداف",
                    tint = GoldRadiant
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(bottom = 90.dp)
        ) {
            // Overall Daily Achievement Ring
            item {
                LuxuryCard(borderAlpha = 0.5f) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "إنجاز الورد اليوم",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "مجموع التزامك بالصلوات والقرآن والذكر ومحاسبة النفس لليوم",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        CounterProgressRing(
                            progress = overallScore,
                            size = 84.dp,
                            strokeWidth = 7.dp
                        ) {
                            Text(
                                text = "${(overallScore * 100).toInt()}%",
                                style = MaterialTheme.typography.titleMedium,
                                color = GoldAccent,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Target 1: Prayers (الصلوات الخمس)
            item {
                LuxuryCard(onClick = { onNavigate("prayer_times") }) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.size(44.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Mosque, contentDescription = null, tint = GoldRadiant)
                            }
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "المحافظة على الصلوات الخمس",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            LinearProgressIndicator(
                                progress = { prayerProgress },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = GoldRadiant,
                                trackColor = MaterialTheme.colorScheme.surfaceVariant
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "$completedPrayers / 5",
                            style = MaterialTheme.typography.titleSmall,
                            color = GoldAccent,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Target 2: Adhkar (الأذكار والأدعية)
            item {
                LuxuryCard(onClick = { onNavigate("adhkar") }) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.size(44.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.WbSunny, contentDescription = null, tint = GoldRadiant)
                            }
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "أذكار الصباح والمساء واليوم",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            LinearProgressIndicator(
                                progress = { dhikrProgress },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = GoldRadiant,
                                trackColor = MaterialTheme.colorScheme.surfaceVariant
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "$completedDhikrCount مكتمل",
                            style = MaterialTheme.typography.titleSmall,
                            color = GoldAccent,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Target 3: Tasbih (السبحة الإلكترونية)
            item {
                LuxuryCard(onClick = { onNavigate("tasbih") }) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.size(44.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.TouchApp, contentDescription = null, tint = GoldRadiant)
                            }
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "تسبيح واستغفار بالسبحة",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            LinearProgressIndicator(
                                progress = { tasbihProgress },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = GoldRadiant,
                                trackColor = MaterialTheme.colorScheme.surfaceVariant
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "$totalTasbihToday / ${userSettings.dailyTasbihTarget}",
                            style = MaterialTheme.typography.titleSmall,
                            color = GoldAccent,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Target 4: Quran Reading
            item {
                LuxuryCard(onClick = { onNavigate("quran") }) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.size(44.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.MenuBook, contentDescription = null, tint = GoldRadiant)
                            }
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "قراءة القرآن الكريم",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "الهدف: ${userSettings.dailyQuranPagesTarget} صفحات يومياً (آخر قراءة: سورة ${userSettings.lastReadSurahName})",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "متابعة ←",
                            style = MaterialTheme.typography.labelMedium,
                            color = GoldRadiant
                        )
                    }
                }
            }

            // Target 5: Nightly Muhasaba
            item {
                LuxuryCard(onClick = { onNavigate("muhasaba") }) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.size(44.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.SelfImprovement, contentDescription = null, tint = GoldRadiant)
                            }
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "خلوة أُنسي ومحاسبة النفس",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = if (muhasabaRecord != null) "أتممت خلوتك الليلة بحمد الله ✓" else "موصى بها قبل النوم لتصفية القلب",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (muhasabaRecord != null) GoldRadiant else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }

    if (showEditGoalsDialog) {
        AlertDialog(
            onDismissRequest = { showEditGoalsDialog = false },
            title = { Text("تعديل أهداف الورد اليومي") },
            text = {
                Column {
                    OutlinedTextField(
                        value = editTasbihText,
                        onValueChange = { editTasbihText = it },
                        label = { Text("هدف التسبيح اليومي (مثلاً 100)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = editQuranText,
                        onValueChange = { editQuranText = it },
                        label = { Text("هدف صفحات القرآن يومياً (مثلاً 4)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val tasbih = editTasbihText.toIntOrNull() ?: 100
                        val quran = editQuranText.toIntOrNull() ?: 4
                        viewModel.setDailyTargets(tasbih, quran)
                        showEditGoalsDialog = false
                    }
                ) {
                    Text("حفظ الأهداف")
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditGoalsDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}

// 2. Statistics & Progress Dashboard (الإحصائيات والتقدم)
@Composable
fun StatisticsScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val tasbihCounters by viewModel.tasbihCounters.collectAsState()
    val progressList by viewModel.dhikrProgressList.collectAsState()
    val muhasabaHistory by viewModel.allMuhasabaHistory.collectAsState()

    val totalLifetimeTasbih = tasbihCounters.sumOf { it.totalLifetimeCount }
    val totalDhikrCompleted = progressList.count { it.isCompleted }
    val muhasabaCount = muhasabaHistory.size

    var showClearDataDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        // Top Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "رجوع",
                    tint = MaterialTheme.colorScheme.onBackground
                )
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "سجل الإحصائيات والالتزام",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onBackground,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "مؤشرات إيمانية خاصة بك دون منافسة",
                    style = MaterialTheme.typography.labelSmall,
                    color = GoldRadiant
                )
            }

            IconButton(
                onClick = {
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(
                            Intent.EXTRA_TEXT,
                            "تقرير إيماني من تطبيق «أُنسي»:\n• إجمالي التسبيحات: $totalLifetimeTasbih\n• جلسات المحاسبة المكتملة: $muhasabaCount\n• الأذكار المنجزة: $totalDhikrCompleted\n«أُنسي - رفيقك إلى الله»"
                        )
                    }
                    context.startActivity(Intent.createChooser(shareIntent, "مشاركة التقرير"))
                }
            ) {
                Icon(
                    imageVector = Icons.Default.Share,
                    contentDescription = "مشاركة التقرير",
                    tint = GoldRadiant
                )
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(bottom = 90.dp)
        ) {
            // Lifetime Tasbih Metric Card
            item {
                LuxuryCard(borderAlpha = 0.5f) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "إجمالي التسبيحات والاستغفار المسجلة",
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "$totalLifetimeTasbih",
                            style = MaterialTheme.typography.displayLarge,
                            color = GoldAccent,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "تسبيحة وتحميدة وتكبيرة واستغفار حفظت في ميزانك بإذن الله",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            // Detailed Counters breakdown
            item {
                Text(
                    text = "تفصيل جلسات السبحة الإلكترونية:",
                    style = MaterialTheme.typography.titleSmall,
                    color = GoldRadiant,
                    fontWeight = FontWeight.Bold
                )
            }

            items(tasbihCounters) { counter ->
                LuxuryCard(borderAlpha = 0.3f) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = counter.titleArabic,
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "الجلسة الحالية: ${counter.count}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            text = "${counter.totalLifetimeCount}",
                            style = MaterialTheme.typography.titleMedium,
                            color = GoldAccent,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Muhasaba History Summary
            item {
                LuxuryCard(borderAlpha = 0.4f) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp)
                    ) {
                        Text(
                            text = "جلسات خلوة أُنسي المكتملة: $muhasabaCount ليلة",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "حرصك على وقفة الصدق مع النفس ينير بصيرتك ويجدد عزيمتك",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Clear All Data Option (Privacy Policy mandate)
            item {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .clickable { showClearDataDialog = true },
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.4f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteForever,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.error
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "حذف سجلاتي وبياناتي الشخصية",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.error,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "تصفير جميع عدادات التسبيح وخلوات المحاسبة وسجل القراءة محلياً",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }

    if (showClearDataDialog) {
        AlertDialog(
            onDismissRequest = { showClearDataDialog = false },
            title = { Text("تأكيد مسح جميع البيانات") },
            text = { Text("هل أنت متأكد من رغبتك في حذف جميع السجلات والمفضلة وجلسات المحاسبة نهائياً؟ هذا الإجراء لا يمكن التراجع عنه.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.clearAllUserData()
                        showClearDataDialog = false
                    }
                ) {
                    Text("نعم، احذف كل شيء", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearDataDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}
