package com.example.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.example.MainActivity
import com.example.R
import com.example.data.repository.AdhkarRepository
import com.example.data.repository.PrayerTimesCalculator
import com.example.data.repository.QuranRepository

// 1. Tasbih Widget
class TasbihWidgetReceiver : AppWidgetProvider() {

    companion object {
        const val ACTION_INCREMENT = "com.example.ACTION_TASBIH_INCREMENT"
        private const val PREFS_NAME = "unsi_widget_tasbih"
        private const val KEY_COUNT = "tasbih_count"

        fun updateWidget(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int) {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val count = prefs.getInt(KEY_COUNT, 0)

            val views = RemoteViews(context.packageName, R.layout.widget_tasbih)
            views.setTextViewText(R.id.widget_tasbih_count, count.toString())

            // Intent to increment
            val incrementIntent = Intent(context, TasbihWidgetReceiver::class.java).apply {
                action = ACTION_INCREMENT
            }
            val incrementPendingIntent = PendingIntent.getBroadcast(
                context,
                0,
                incrementIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_tasbih_btn, incrementPendingIntent)

            // Open app on click title/root
            val appIntent = Intent(context, MainActivity::class.java).apply {
                putExtra("destination", "tasbih")
            }
            val appPendingIntent = PendingIntent.getActivity(
                context,
                1,
                appIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_tasbih_root, appPendingIntent)

            appWidgetManager.updateAppWidget(appWidgetId, views)
        }
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) {
            updateWidget(context, appWidgetManager, id)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_INCREMENT) {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val current = prefs.getInt(KEY_COUNT, 0)
            prefs.edit().putInt(KEY_COUNT, current + 1).apply()

            val appWidgetManager = AppWidgetManager.getInstance(context)
            val ids = appWidgetManager.getAppWidgetIds(
                ComponentName(context, TasbihWidgetReceiver::class.java)
            )
            for (id in ids) {
                updateWidget(context, appWidgetManager, id)
            }
        }
    }
}

// 2. Prayer Times Widget
class PrayerWidgetReceiver : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        val prayerTimes = PrayerTimesCalculator.calculatePrayerTimes(21.4225, 39.8262)
        for (id in appWidgetIds) {
            val views = RemoteViews(context.packageName, R.layout.widget_prayer)
            views.setTextViewText(R.id.widget_prayer_name, "صلاة ${prayerTimes.nextPrayerName}")
            val time = when (prayerTimes.nextPrayerName) {
                "الفجر" -> prayerTimes.fajr
                "الظهر" -> prayerTimes.dhuhr
                "العصر" -> prayerTimes.asr
                "المغرب" -> prayerTimes.maghrib
                "العشاء" -> prayerTimes.isha
                else -> prayerTimes.fajr
            }
            views.setTextViewText(R.id.widget_prayer_time, time)
            views.setTextViewText(R.id.widget_prayer_remaining, "متبقي ${prayerTimes.minutesRemaining} دقيقة")

            val appIntent = Intent(context, MainActivity::class.java).apply {
                putExtra("destination", "prayer_times")
            }
            val pendingIntent = PendingIntent.getActivity(
                context, 2, appIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_prayer_root, pendingIntent)

            appWidgetManager.updateAppWidget(id, views)
        }
    }
}

// 3. Dhikr Widget
class DhikrWidgetReceiver : AppWidgetProvider() {
    companion object {
        const val ACTION_NEXT = "com.example.ACTION_DHIKR_NEXT"
        private const val PREFS_NAME = "unsi_widget_dhikr"
        private const val KEY_INDEX = "dhikr_index"

        fun updateWidget(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int) {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val idx = prefs.getInt(KEY_INDEX, 0)
            val category = AdhkarRepository.getDhikrByCategory("general")
            val item = if (category.isNotEmpty()) category[idx % category.size] else AdhkarRepository.getDailyDhikr()

            val views = RemoteViews(context.packageName, R.layout.widget_dhikr)
            views.setTextViewText(R.id.widget_dhikr_text, item.textArabic)
            views.setTextViewText(R.id.widget_dhikr_fadhil, item.fadilah)

            val nextIntent = Intent(context, DhikrWidgetReceiver::class.java).apply {
                action = ACTION_NEXT
            }
            val nextPendingIntent = PendingIntent.getBroadcast(
                context, 3, nextIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_dhikr_next_btn, nextPendingIntent)

            val appIntent = Intent(context, MainActivity::class.java).apply {
                putExtra("destination", "adhkar")
            }
            val appPendingIntent = PendingIntent.getActivity(
                context, 4, appIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_dhikr_root, appPendingIntent)

            appWidgetManager.updateAppWidget(appWidgetId, views)
        }
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) {
            updateWidget(context, appWidgetManager, id)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_NEXT) {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val current = prefs.getInt(KEY_INDEX, 0)
            prefs.edit().putInt(KEY_INDEX, current + 1).apply()

            val appWidgetManager = AppWidgetManager.getInstance(context)
            val ids = appWidgetManager.getAppWidgetIds(
                ComponentName(context, DhikrWidgetReceiver::class.java)
            )
            for (id in ids) {
                updateWidget(context, appWidgetManager, id)
            }
        }
    }
}

// 4. Wird Widget
class WirdWidgetReceiver : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) {
            val views = RemoteViews(context.packageName, R.layout.widget_wird)
            val appIntent = Intent(context, MainActivity::class.java).apply {
                putExtra("destination", "wird_plan")
            }
            val pendingIntent = PendingIntent.getActivity(
                context, 5, appIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_wird_root, pendingIntent)
            appWidgetManager.updateAppWidget(id, views)
        }
    }
}

// 5. Ayah Widget
class AyahWidgetReceiver : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        val (ayah, ref) = QuranRepository.getDailyAyah()
        for (id in appWidgetIds) {
            val views = RemoteViews(context.packageName, R.layout.widget_ayah)
            views.setTextViewText(R.id.widget_ayah_text, "﴿ ${ayah.textArabic} ﴾")
            views.setTextViewText(R.id.widget_ayah_reference, "[$ref]")

            val appIntent = Intent(context, MainActivity::class.java).apply {
                putExtra("destination", "quran")
            }
            val pendingIntent = PendingIntent.getActivity(
                context, 6, appIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_ayah_root, pendingIntent)
            appWidgetManager.updateAppWidget(id, views)
        }
    }
}

// 6. Muhasaba Widget
class MuhasabaWidgetReceiver : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) {
            val views = RemoteViews(context.packageName, R.layout.widget_muhasaba)
            val appIntent = Intent(context, MainActivity::class.java).apply {
                putExtra("destination", "muhasaba")
            }
            val pendingIntent = PendingIntent.getActivity(
                context, 7, appIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_muhasaba_root, pendingIntent)
            appWidgetManager.updateAppWidget(id, views)
        }
    }
}
