package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Build
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class ReciterInfo(
    val id: String,
    val nameArabic: String,
    val serverBaseUrl: String
)

data class AudioTrack(
    val title: String,
    val subtitle: String,
    val url: String,
    val surahNumber: Int = 1
)

enum class PlayerState {
    IDLE,
    PREPARING,
    PLAYING,
    PAUSED,
    ERROR
}

class AudioPlayerManager(private val context: Context) {

    private var mediaPlayer: MediaPlayer? = null
    private val scope = CoroutineScope(Dispatchers.Main + Job())
    private var progressJob: Job? = null

    private val _playerState = MutableStateFlow(PlayerState.IDLE)
    val playerState: StateFlow<PlayerState> = _playerState.asStateFlow()

    private val _currentTrack = MutableStateFlow<AudioTrack?>(null)
    val currentTrack: StateFlow<AudioTrack?> = _currentTrack.asStateFlow()

    private val _currentPositionMs = MutableStateFlow(0)
    val currentPositionMs: StateFlow<Int> = _currentPositionMs.asStateFlow()

    private val _durationMs = MutableStateFlow(0)
    val durationMs: StateFlow<Int> = _durationMs.asStateFlow()

    private val _playbackSpeed = MutableStateFlow(1.0f)
    val playbackSpeed: StateFlow<Float> = _playbackSpeed.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    val availableReciters: List<ReciterInfo> = listOf(
        ReciterInfo("alafasy", "الشيخ مشاري راشد العفاسي", "https://server8.mp3quran.net/afs/"),
        ReciterInfo("abdulbasit", "الشيخ عبد الباسط عبد الصمد (مرتل)", "https://server7.mp3quran.net/basit/"),
        ReciterInfo("alghamdi", "الشيخ سعد الغامدي", "https://server7.mp3quran.net/s_gmd/"),
        ReciterInfo("minshawi", "الشيخ محمد صديق المنشاوي", "https://server10.mp3quran.net/minsh/")
    )

    private val _selectedReciter = MutableStateFlow(availableReciters[0])
    val selectedReciter: StateFlow<ReciterInfo> = _selectedReciter.asStateFlow()

    fun selectReciter(reciter: ReciterInfo) {
        _selectedReciter.value = reciter
        _currentTrack.value?.let { track ->
            playSurah(track.surahNumber, track.title)
        }
    }

    fun playSurah(surahNumber: Int, surahName: String) {
        val formattedNum = String.format("%03d", surahNumber)
        val audioUrl = "${_selectedReciter.value.serverBaseUrl}$formattedNum.mp3"
        val track = AudioTrack(
            title = "سورة $surahName",
            subtitle = _selectedReciter.value.nameArabic,
            url = audioUrl,
            surahNumber = surahNumber
        )
        playTrack(track)
    }

    fun playTrack(track: AudioTrack) {
        stop()
        _currentTrack.value = track
        _playerState.value = PlayerState.PREPARING
        _errorMessage.value = null

        try {
            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                setDataSource(track.url)
                setOnPreparedListener { mp ->
                    _durationMs.value = mp.duration
                    applyPlaybackSpeed(_playbackSpeed.value)
                    mp.start()
                    _playerState.value = PlayerState.PLAYING
                    startProgressTracker()
                }
                setOnCompletionListener {
                    _playerState.value = PlayerState.PAUSED
                    _currentPositionMs.value = 0
                    stopProgressTracker()
                }
                setOnErrorListener { _, what, extra ->
                    _playerState.value = PlayerState.ERROR
                    _errorMessage.value = "تعذر تشغيل التسجيل الصوتي. يرجى التحقق من الاتصال بالإنترنت."
                    stopProgressTracker()
                    true
                }
                prepareAsync()
            }
        } catch (e: Exception) {
            _playerState.value = PlayerState.ERROR
            _errorMessage.value = "تعذر بدء المشغل: ${e.localizedMessage}"
        }
    }

    fun togglePlayPause() {
        val player = mediaPlayer ?: return
        if (player.isPlaying) {
            player.pause()
            _playerState.value = PlayerState.PAUSED
            stopProgressTracker()
        } else {
            player.start()
            _playerState.value = PlayerState.PLAYING
            startProgressTracker()
        }
    }

    fun seekTo(positionMs: Int) {
        mediaPlayer?.let {
            it.seekTo(positionMs)
            _currentPositionMs.value = positionMs
        }
    }

    fun setSpeed(speed: Float) {
        _playbackSpeed.value = speed
        applyPlaybackSpeed(speed)
    }

    private fun applyPlaybackSpeed(speed: Float) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            mediaPlayer?.let { mp ->
                try {
                    mp.playbackParams = mp.playbackParams.setSpeed(speed)
                } catch (e: Exception) {
                    // Ignored on unsupported devices
                }
            }
        }
    }

    fun skipForward10Sec() {
        val newPos = (_currentPositionMs.value + 10000).coerceAtMost(_durationMs.value)
        seekTo(newPos)
    }

    fun skipBackward10Sec() {
        val newPos = (_currentPositionMs.value - 10000).coerceAtLeast(0)
        seekTo(newPos)
    }

    private fun startProgressTracker() {
        stopProgressTracker()
        progressJob = scope.launch {
            while (isActive && mediaPlayer != null) {
                try {
                    if (mediaPlayer?.isPlaying == true) {
                        _currentPositionMs.value = mediaPlayer?.currentPosition ?: 0
                    }
                } catch (e: Exception) {
                    // Ignore state races
                }
                delay(500)
            }
        }
    }

    private fun stopProgressTracker() {
        progressJob?.cancel()
        progressJob = null
    }

    fun stop() {
        stopProgressTracker()
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
        } catch (e: Exception) {
            // Ignored
        }
        mediaPlayer = null
        _playerState.value = PlayerState.IDLE
        _currentPositionMs.value = 0
    }

    fun release() {
        stop()
    }
}
